"""
code  written by junghun Chae

If you have any question, please email to the following address.
wjdgnswkd612@gmail.com

Readme
"freex" variable refers to "x_0(t)".
parameter 'c' refers to 'r0'.
"R" refers [x'(t)/x(t)] with dimension of 1/r0.
"Rmax" refers maximum of R with dimension of 1/r0.
substrate_sum in equation_Full function is "total protein abundance - x_0(t)".
alphaD is equal to alpha_r(t).
"""
#-*-coding: utf-8 -*-

import numpy as np
from scipy.interpolate import interp1d
import scipy.interpolate as inp
from scipy.integrate import trapz
from scipy.integrate import solve_ivp
import random as rd

def similarity1(x1, x2, t):
    ## similarity 1 calculation.
    ## input :
    ## x1, x2 : two profile(time series data) to calculate the similarity1 index.
    ## t : time point of the x1 and x2 time series data.
    ##
    ## output :
    ## simiarity1 index between x1 and x2 profile.

    max_fun = []
    min_fun = []
    for idx, i in enumerate(t):
        max_fun.append(max(x1[idx], x2[idx]))
        min_fun.append(min(x1[idx], x2[idx]))
    max_area = trapz(max_fun,t)
    min_area = trapz(min_fun,t)

    return min_area/max_area

def linear_fun(a, c, x):
    ## calculate linear function and return function value of given x.
    ## input :
    ## a : tangent of the linear function
    ## c : array of one point on the line
    ## c[0] : x position of the point
    ## c[1] : y position of the point
    ## x : x position of where you want to estimate the function value
    ## output :
    ## function value of the given x position x

    return a*(x-c[0])+c[1]

def read_PER2_original():
    ## read PER2 protein profile data
    ## input : none
    ## ouput :
    ## t_P2 : time points of PER2 protien profile data.
    ## x_P2 : PER2 protein profile time series data.

    file_P2 = open("PER2_profile.txt",'r')
    data_P2 = file_P2.read()
    file_P2.close()

    data_P2 = data_P2.split("\n")
    data_P2.pop()

    Per2_data = []
    for i in data_P2:
        Per2_data.append(i.split("\t"))

    t_P2 = []
    x_P2 = []
    R_P2 = []
    Per2_data = np.array(Per2_data)

    for i in Per2_data[:,0]:
        t_P2.append(float(i)/10)
    for i in Per2_data[:,1]:
        x_P2.append(float(i))

    ## repetiting PER2 data for 5 times to make oscillation
    t_rep = []
    x_rep = []
    for i in range(10):
        for jidx, j in enumerate(t_P2):
            t_rep.append(j-24*(2-i))
            x_rep.append(x_P2[jidx])

    return (t_rep, x_rep)

def equation_Full(y,t , para, para0, para1, para2, para3, para_beta, Xprof):
    ## The main equations of the ode system.
    ## input :
    ## y : array of protein substrate component at time t.
    ## para : parameters related to ubiquitination for free substrate.
    ## para0 : parameters related to ubiquitination for 1 times phosphorylated substrate at FASP sites.
    ## para1 : parameters related to ubiquitination for 2 times phosphorylated substrate at FASP sites.
    ## para2 : parameters related to ubiquitination for 3 times phosphorylated substrate at FASP sites.
    ## para3 : parameters related to ubiquitination for 4 times phosphorylated substrate at FASP sites.
    ## para_beta : parameters related to ubiquitination for 1 times phosphorylated substrate at beta_trcp sites.
    ## t : time
    ## para : parameters
    ## return :
    ## dxvardt = dy/dt

    a00=para[0]
    a01=para[1]
    a02=para[2]
    b00=para[3]
    b01=para[4]
    k=para[5]
    ll=para[6]
    q0=para[7]
    s0=para[8]
    c0=para[10]
    u=para[13]
    v=para[14]
    yy=para[15]
    z=para[16]

    a10=para0[0]
    a11=para0[1]
    a12=para0[2]
    b10=para0[3]
    b11=para0[4]
    k1=para0[5]
    ll1=para0[6]
    q1=para0[7]
    s1=para0[8]
    c1=para0[10]

    a20=para1[0]
    a21=para1[1]
    a22=para1[2]
    b20=para1[3]
    b21=para1[4]
    k2=para1[5]
    ll2=para1[6]
    q2=para1[7]
    s2=para1[8]
    c2=para1[10]

    a30=para2[0]
    a31=para2[1]
    a32=para2[2]
    b30=para2[3]
    b31=para2[4]
    k3=para2[5]
    ll3=para2[6]
    q3=para2[7]
    s3=para2[8]
    c3=para2[10]

    a40=para3[0]
    a41=para3[1]
    a42=para3[2]
    b40=para3[3]
    b41=para3[4]
    k4=para3[5]
    ll4=para3[6]
    q4=para3[7]
    s4=para3[8]
    c4=para3[10]

    #beta trcp
    a0_beta=para_beta[0]
    a1_beta=para_beta[1]
    a2_beta=para_beta[2]
    b0_beta=para_beta[3]
    b1_beta=para_beta[4]
    k_beta=para_beta[5]
    ll_beta=para_beta[6]
    q_beta=para_beta[7]
    s_beta=para_beta[8]
    c_beta=para_beta[10]
    u_beta=para_beta[13]
    v_beta=para_beta[14]

    x0=y[0]; xeo0=y[1]; xeub0=y[2]; xoub0=y[3]; xhub0=y[4];

    # phosphorylation at FASP site for 1, 2, 3, 4 times
    xp1=y[5]; xp2=y[6]; xp3=y[7]; xp4=y[8]

    # 1 phosphorylation at FASP site
    xeo1=y[9]; xeub1=y[10]; xoub1=y[11]; xhub1=y[12];

    # 2 phosphorylations at FASP site
    xeo2=y[13]; xeub2=y[14]; xoub2=y[15]; xhub2=y[16];

    # 3 phosphorylations at FASP site
    xeo3=y[17]; xeub3=y[18]; xoub3=y[19]; xhub3=y[20];

    # 4 phosphorylations at FASP site
    xeo4=y[21]; xeub4=y[22]; xoub4=y[23]; xhub4=y[24];

    # phosphorylation at beta_trcp site
    xp_beta=y[25]; xeo_beta=y[26]; xeub_beta=y[27]; xoub_beta=y[28]; xhub_beta=y[29];

    u=u-xeo0-xeub0-xeo1-xeub1-xeo2-xeub2-xeo3-xeub3-xeo4-xeub4

    v=v-xhub0-xhub1-xhub2-xhub3-xhub4

    u_beta=u_beta-xeo_beta-xeub_beta

    v_beta=v_beta-xhub_beta

    #free substrate x
    tot_d1=0
    for i in y:
        tot_d1 += i
    freex= Xprof(t)-tot_d1

    #free substrate x
    dxdt=0

    dxeo0dt=a00*u*freex-a01*xeo0-q0*xeo0+s0*xhub0

    dxeub0dt=q0*xeo0+a00*u*xoub0-a02*xeub0-c0*xeub0

    dxoub0dt=a02*xeub0+b01*xhub0-b00*v*xoub0-a00*u*xoub0-c0*xoub0

    dxhub0dt=b00*v*xoub0-b01*xhub0-s0*xhub0-c0*xhub0

    #one phosphorylation at FASP site
    dxp1dt=k[0]*yy*freex - k[1]*yy*xp1 - a10*u*xp1 + a11*xeo1 + s1*xhub1 - ll[0]*z*xp1 + ll[1]*z*xp2

    dxeo1dt=a10*u*xp1-a11*xeo1-q1*xeo1

    dxeub1dt=q1*xeo1+a10*u*xoub1-a12*xeub1-c1*xeub1

    dxoub1dt=a12*xeub1+b11*xhub1-b10*v*xoub1-a10*u*xoub1-c1*xoub1

    dxhub1dt= -b11*xhub1 + b10*v*xoub1 - s1*xhub1 - c1*xhub1

    #two phosphorylations at FASP site
    dxp2dt=-k[2]*yy*xp2+k[1]*yy*xp1 - a20*u*xp2 + a21*xeo2 + s2*xhub2 - ll[1]*z*xp2 + ll[2]*z*xp3

    dxeo2dt=a20*u*xp2-a21*xeo2-q2*xeo2

    dxeub2dt=q2*xeo2+a20*u*xoub2-a22*xeub2-c2*xeub2

    dxoub2dt=a22*xeub2+b21*xhub2-b20*v*xoub2-a20*u*xoub2-c2*xoub2

    dxhub2dt=-b21*xhub2+b20*v*xoub2- s2*xhub2 - c2*xhub2

    #three phosphorylations at FASP site
    dxp3dt=-k[3]*yy*xp3+k[2]*yy*xp2-a30*u*xp3+a31*xeo3+s3*xhub3   - ll[2]*z*xp3 + ll[3]*z*xp2

    dxeo3dt=a30*u*xp3-a31*xeo3-q3*xeo3

    dxeub3dt=q3*xeo3+a30*u*xoub3-a32*xeub3-c3*xeub3

    dxoub3dt=a32*xeub3+b31*xhub3-b30*v*xoub3-a30*u*xoub3-c3*xoub3

    dxhub3dt=-b31*xhub3 + b30*v*xoub3 - s3*xhub3 - c3*xhub3

    #four phosphorylations at FASP site
    dxp4dt=k[3]*yy*xp3-a40*u*xp4+a41*xeo4+s4*xhub4 - ll[3]*z*xp4

    dxeo4dt=a40*u*xp4-a41*xeo4-q4*xeo4

    dxeub4dt=q4*xeo4+a40*u*xoub4-a42*xeub4-c4*xeub4

    dxoub4dt=a42*xeub4+b41*xhub4-b40*v*xoub4-a40*u*xoub4-c4*xoub4

    dxhub4dt=-b41*xhub4+b40*v*xoub4-s4*xhub4-c4*xhub4


    #one phosphorylation at beta-TRCP site
    dxp_betadt=k_beta*yy*freex - a0_beta*u_beta*xp_beta + a1_beta*xeo_beta + s_beta*xhub_beta - ll_beta*z*xp_beta

    dxeo_betadt=a0_beta*u_beta*xp_beta-a1_beta*xeo_beta-q_beta*xeo_beta

    dxeub_betadt=q_beta*xeo_beta+a0_beta*u_beta*xoub_beta-a2_beta*xeub_beta-c_beta*xeub_beta

    dxoub_betadt=a2_beta*xeub_beta+b1_beta*xhub_beta-b0_beta*v_beta*xoub_beta-a0_beta*u_beta*xoub_beta-c_beta*xoub_beta

    dxhub_betadt= -b1_beta*xhub_beta + b0_beta*v_beta*xoub_beta - s_beta*xhub_beta - c_beta*xhub_beta


    return [dxdt,dxeo0dt,dxeub0dt,dxoub0dt, dxhub0dt, dxp1dt, dxp2dt, dxp3dt, dxp4dt,\
            dxeo1dt,dxeub1dt,dxoub1dt, dxhub1dt,\
            dxeo2dt,dxeub2dt,dxoub2dt, dxhub2dt,\
            dxeo3dt,dxeub3dt,dxoub3dt, dxhub3dt,\
            dxeo4dt,dxeub4dt,dxoub4dt, dxhub4dt,\
            dxp_betadt, dxeo_betadt,dxeub_betadt,dxoub_betadt, dxhub_betadt]

def rt_est(t, R, P2_expt, P2_expD, t_eval):
    ## function that generates interpolation fucntion of estimated r(t).
    ## input :
    ## R : array of R (-1/x*dx/dt)(it has dimension of 1/c).
    ## t : array of time points for R
    ## P2_expt : experimentally measured time points of r(t)
    ## P2_expD : experimentally measured r(t).
    ## t_eval : array of time points for interpolation
    ## output :
    ## inp_rt_est : interpolation function that returns r(t) estimated value at given time point t.

    R2_inp = interp1d(t, R, kind = "cubic")
    alist = np.linspace(0.04,0,1000)
    time_range = np.linspace(30,40, 10000)

    R2_search = []
    for i in time_range:
        R2_search.append(R2_inp(i))
    a2_min = 0
    t2_met = 0
    for i in alist:
        lin = []
        for j in time_range:
            lin.append(linear_fun(i, [P2_expt[-1], P2_expD[-1]], j))

        dif = (np.array(lin)-np.array(R2_search))
        if dif.min()<0:
            a2_min = i
            t2_met = time_range[ int(np.where(dif == dif.min())[0]) ]
            break

    maxT = 0
    for idx, i in enumerate(R):
        if i > P2_expD[0]:
            maxT = t[idx]
        if t_eval[idx] > 20:
            break

    t_range = np.linspace(10,34,int(24/0.01)+1)

    D2_t_cubic = []
    D2_est_cubic = []

    for tidx, t in enumerate(t_range):
        if t >= t2_met -24 and t < maxT :
            D2_t_cubic.append(t)
            D2_est_cubic.append(R2_inp(t))

    D2_t_cubic += [maxT+0.01*i for i in range(1, 31)]
    D2_est_cubic += [P2_expD[0] for i in range(30)]

    D2_t_cubic += [P2_expt[0]-0.33+(i*0.01) for i in range(1, 31)]+P2_expt+[t2_met]
    D2_est_cubic += [P2_expD[0] for i in range(30)]+P2_expD+[linear_fun(a2_min, [P2_expt[-1], P2_expD[-1]], t2_met)]

    D2_t_cubic_full = []
    D2_est_cubic_full = []

    for i in range(10):
        for jidx, j in enumerate(D2_t_cubic):
            D2_t_cubic_full.append(j-24*(2-i))
            D2_est_cubic_full.append(D2_est_cubic[jidx])

    D2_cubic_inp = []
    inp_rt_est = inp.interp1d(D2_t_cubic_full, D2_est_cubic_full, kind = "linear")

    return  inp_rt_est

def findMaxMin(x, t, howlong, DPeriod = 24, NdayDelete = 3):
    ## find peak and trough value of give give profile.
    ## input :
    ## x : time series data of given profile
    ## t : array of time points for profile x.
    ## howlong : the total lengh of the time series.
    ## DPeriod : the oscillation Period.  defult is 24 hours
    ## NdayDelete : time it takes to begin oscillation.
    ## it deletes initial 3 days of time series for default.
    ## output :
    ## array of peak and trough value

    length = len(t)
    aDay = int(length/howlong*DPeriod)
    Days = int(howlong/DPeriod)-1
    mini = []
    maxi = []

    for i in range(NdayDelete,Days):
        maxi.append(-1000)
        mini.append(1000)
        for idx in range(aDay):
            if maxi[i-NdayDelete]<x[i*aDay+idx]:
                maxi[i-NdayDelete] = x[i*aDay+idx]

            if mini[i-NdayDelete]>x[i*aDay+idx]:
                mini[i-NdayDelete] = x[i*aDay+idx]

    avgmini = 0
    avgmaxi = 0

    for i in range(Days-NdayDelete):
        avgmaxi = avgmaxi+maxi[i]/(Days-NdayDelete)
        avgmini = avgmini+mini[i]/(Days-NdayDelete)
    return [avgmaxi,avgmini]

def ode_solve(para_list, Xmax, Xmin, Rmax, R, Xtot, dt, t, rt_est_Per2, Xprof):
    ## solve ode and write file
    ##
    ## input :
    ## para : parameters
    ## Xmax : maximum value of x profile
    ## Xmin : minimum value of x profile
    ## Rmax : maximum value of R
    ## R    : time series of R ([x'(t)/x(t)] it has dimension of 1/c)
    ## Xtot : x protein profile
    ## dt   : minimum time step
    ## t    : evaluating time points
    ##
    ## output :
    ## there is no function return.
    ## this function writes files
    ## it writes following values
    ## parameters   : parameters to generate the profile
    ## feasible     : 0 if the profile satisfies feasible condition, 1 if not.
    ## cost         : time average of total proten synthesis during one period
    ## alpha r(t)   : alpha value of r(t) profile
    ## sim          : similarity value of r(t) simulation compared with r(t) estimation


    xnew=solve_ivp(fun=lambda  t,y: equation_Full(y, t, para_list[0],para_list[1],para_list[2],para_list[3],para_list[4],para_list[5], Xprof),\
                        y0=[0 for i in range(30)], t_eval=t, t_span=[0, t[-1]], method="LSODA", atol=1e-5, rtol=1e-5)

    t = xnew.t

    subtrate_sum = 0
    for i in range(30):
        subtrate_sum = subtrate_sum+xnew.y[i]
    freex = Xtot - subtrate_sum

    #r(t) profile made by this simulation
    D_index_list = [2,3,4,10,11,12,14,15,16,18,19,20,22,23,24,27,28,29]
    rt_sim = 0
    for idx, index in enumerate(D_index_list):
        rt_sim += xnew.y[index] * para_list[int(idx/3)][10]
    rt_sim=rt_sim/Xtot

    rt_max, rt_min = findMaxMin(rt_sim, t, 24*5, 24, NdayDelete = 2)
    alphaD = 1 - rt_min / rt_max

    feasible = 0

    #free u
    xeo_eub_index_list=[1,2,9,10,13,14,17,18,21,22]

    free_u_FASP = para_list[0][13]
    for index in xeo_eub_index_list:
        free_u_FASP = free_u_FASP - xnew.y[index]

    free_u_beta = para_list[5][13]

    free_u_beta = free_u_beta - xnew.y[26] - xnew.y[27]

    #calculating g profile
    g=(rt_sim-R)*Xtot

    xmin = 0
    for i in range(30):
        if xnew.y[i].min()<0:
            xmin = xnew.y[i].min()
            feasible = 1

    DR_min = (rt_sim-R).min()
    if DR_min < 0:
        feasible = 1

    if freex.min() < 0:
        feasible = 1

    if free_u_beta.min() < 0:
        feasible = 1

    if free_u_FASP.min() < 0:
        feasible = 1

    gmin = g.min()

    if gmin < 0 :
        feasible = 1

    sim = similarity1(rt_sim[int(72/dt):int(96/dt)], rt_est_Per2[int(72/dt):int(96/dt)], xnew.t[int(72/dt):int(96/dt)])
    cost = trapz(g[int(72/dt):int(96/dt)], xnew.t[int(72/dt):int(96/dt)])/24

    return  [para_list, feasible, cost, alphaD, sim]

def main():
    ##PER2 experimental t, r(t) values
    P2_expt = [19, 22, 25, 28, 30]
    P2_expD = [0.110293, 0.157904, 0.169430, 0.256223, 0.278472]

    t_P2, x_P2=read_PER2_original()

    ## interpolation of PER2 protein data.
    ## t_eval : time points to use.
    ## time step is 0.01 hour.
    P2_inp = interp1d(t_P2, x_P2, kind = "cubic")
    t_eval = np.linspace(0,48,int(48/0.01)+1)

    x_inp = []
    for i in t_eval:
        x_inp.append(P2_inp(i))

    ## R with dt=0.01
    R = [0,0]
    for i in range(2,len(t_eval)-2):
        h = t_eval[i+1]-t_eval[i]
        R.append( -1/(x_inp[i])*(-x_inp[i+2]+8*x_inp[i+1]-8*x_inp[i-1]+x_inp[i-2])/12/h  )
    R.append(R[-1])
    R.append(R[-1])


    #window averaing . Window size = 1 hour.
    t_wd = []
    R_wd = []
    for idx, i in enumerate(t_eval):
        x0 = R[idx]
        avg = x0
        num = 1

        t_mov = i
        while(t_mov < i+1 and idx+num< len(t_eval)-1):
            avg = avg+R[idx+num]
            t_mov = t_eval[idx+num]
            num += 1
        avg = avg/num
        t_wd.append((i+t_mov)/2)
        R_wd.append(avg)

    inp_est_rt = rt_est(t_wd,R_wd, P2_expt, P2_expD, t_eval)

    rt_est_PER2 = []
    dt = 0.05

    t_eval2 = np.linspace(0,24*5, int(24*5/dt)+1)

    for j in t_eval2:
        rt_est_PER2.append(inp_est_rt(j))

    Per2_interpolation = interp1d(t_P2, x_P2, kind = 'cubic')

    Period = 24
    big = 0
    fac = 1
    end_FullEquation = 5*Period*fac

    ## maximum timestep
    dt = 0.05

    ## evaluating timepoint
    t = np.linspace(0,end_FullEquation,int(end_FullEquation/dt)+1)

    max_x=max(x_P2)
    ## Xprofile interpolation
    def Xprof(t):
        return Per2_interpolation(t)/max_x*14

    ## X profile array.
    Xtot = []
    for i in t:
        Xtot.append(Xprof(i))

    ##R value interpolation
    fun_Rwd = interp1d(t_wd, R_wd)

    # calculating R with new time intervals.
    R = []
    for i in t:
        if i<1:
            R.append(fun_Rwd(i+24))
        elif i>24:
            R.append(fun_Rwd((i-1)%24+1))
        else:
            R.append(fun_Rwd(i))
    R = np.array(R)

    Rmax = max(R)
    Xmax = max(Xtot)
    Xmin = min(Xtot)

    file = open("./model_PER2_result.csv",'w')
    file.write("a00,a01,a02,b00,b01,q0,s0,r00,\
        a10,a11,a12,b10,b11,k1,l1,q1,s1,r10,\
        a20,a21,a22,b20,b21,k2,l2,q2,s2,r20,\
        a30,a31,a32,b30,b31,k3,l3,q3,s3,r30,\
        a40,a41,a42,b40,b41,k4,l4,q4,s4,r40,\
        abeta0,abeta1,abeta2,bbeta0,bbeta1,kbeta,lbeta,qbeta,sbeta,rbeta0,\
        u,v,ubeta,vbeta,y,z,\
        feasible,cost,alpha_D,similarity\n")
    file.close()

    num_of_trial=1
    for i in range(num_of_trial):
        k_list = [0 for i in range(4)]
        ll_list = [0 for i in range(4)]
        for i in range(4):
            k_list[i] = rd.uniform(0.006,0.06)
            ll_list[i] = rd.uniform(0.006,0.06)

        u = rd.uniform(0.1,1)
        u_beta = rd.uniform(0.1,1)

        v = rd.uniform(0,1)
        v_beta = rd.uniform(0,1)

        y = rd.uniform(30,300)
        z = rd.uniform(0,300)

        para_list=[[0 for i in range(17)] for i in range(6)]
        for para_num in range(6):
            a0=para_list[para_num][0]=rd.uniform(180,4800)
            a1=para_list[para_num][1]=rd.uniform(420,18000)
            a2=para_list[para_num][2]=rd.uniform(180,18000)
            b0=para_list[para_num][3]=rd.uniform(180,4800)
            b1=para_list[para_num][4]=rd.uniform(180,18000)
            para_list[para_num][5]=k_list
            para_list[para_num][6]=ll_list

            if para_num==5:
                para_list[para_num][5]=rd.uniform(0.006,0.06)
                para_list[para_num][6]=rd.uniform(0.006,0.06)

            q=para_list[para_num][7]=rd.uniform(30,1200)
            s=para_list[para_num][8]=rd.uniform(30,1200)

            c=para_list[para_num][10]=rd.uniform(Rmax, 5)

            para_list[para_num][13]=u
            para_list[para_num][14]=v
            para_list[para_num][15]=y
            para_list[para_num][16]=z

        para, feasible, cost, alphaD, sim = ode_solve(para_list, Xmax, Xmin, Rmax, R, Xtot, dt, t, rt_est_PER2, Xprof)

        ## writing file
        file = open("./model_PER2_result.csv",'a')

        for para_num in range(6):
            a0=para_list[para_num][0]
            a1=para_list[para_num][1]
            a2=para_list[para_num][2]
            b0=para_list[para_num][3]
            b1=para_list[para_num][4]

            if para_num==5:
                k=para_list[para_num][5]
                ll=para_list[para_num][6]
            elif para_num > 0 :
                k=k_list[para_num-1]
                ll=ll_list[para_num-1]

            q=para_list[para_num][7]
            s=para_list[para_num][8]

            c=para_list[para_num][10]

            file.write(str(a0)+",")
            file.write(str(a1)+",")
            file.write(str(a2)+",")
            file.write(str(b0)+",")
            file.write(str(b1)+",")
            if para_num > 0 :
                file.write(str(k)+",")
                file.write(str(ll)+",")
            file.write(str(q)+",")
            file.write(str(s)+",")
            file.write(str(c)+",")


        file.write(str(u)+",")
        file.write(str(v)+",")
        file.write(str(u_beta)+",")
        file.write(str(v_beta)+",")
        file.write(str(y)+",")
        file.write(str(z)+",")

        file.write(str(feasible)+",")
        file.write(str(cost)+",")
        file.write(str(alphaD)+",")
        file.write(str(sim)+",")
        file.write("\n")
        file.close()

main()
