File name: PER2_real.py

This python code can be run on Windows 10, Linux or macOS. Python 3.5 or later
is required. The code requires the following Python packages:
- numpy,
- scipy,
- random.
Installing the required Python packages does not take long time (less than 10
minutes).

This code randomly generates parameter values within the physiologically-relevant ranges
for the realistic PER2 degradation model with FASP and beta-TRCP pathways, solves
the model using the given PER2 protein abundance data, and computes
- alpha_D,
- proteosynthetic costs,
- and similarity between simulated r(t) and empirical degradation-rate profile

The parameter ranges are given as follows: 
- 180 nM^-1 h^-1 <= a0_0,a0_1,a0_2,a0_3,a0_4 <= 4800 nM^-1 h^-1
- 420 h^-1 <= a1_0,a1_1,a1_2,a1_3,a1_4 <= 18000 h^-1
- 180 h^-1 <= a2_0,a2_1,a2_2,a2_3,a2_4 <= 18000 h^-1
- 180 nM^-1 h^-1 <= b0_0,b0_1,b0_2,b0_3,b0_4 <= 4800 nM^-1 h^-1
- 180 h^-1 <= b1_0,b1_1,b1_2,b1_3,b1_4 <= 18000 h^-1
- -x'(t)/x(t) h^-1 <= r0_0,r0_1,r0_2,r0_3,r0_4 <= 5 h^-1
- 0.006 nM^-1 h^-1 <= k_1,k_2,k_3,k_4 <= 0.06 nM^-1 h^-1
- 0.006 nM^-1 h^-1 <= l_1,l_2,l_3,l_4 <= 0.06 nM^-1 h^-1
- 30 h^-1 <= q_0,q_1,q_2,q_3,q_4 <= 1200 h^-1
- 30 h^-1 <= s_0,s_1,s_2,s_3,s_4 <= 1200 h^-1
- 0.1 <= u <= 1 nM
- 0 <= v <= 1 nM
- 30 <= y <= 300 nM
- 0 <= z <= 300 nM
- 180 nM^-1 h^-1 <= a0_beta <= 4800 nM^-1 h^-1
- 420 h^-1 <= a1_beta <= 18000 h^-1
- 180 h^-1 <= a2_beta <= 18000 h^-1
- 180 nM^-1 h^-1 <= b0_beta <= 4800 nM^-1 h^-1
- 180 h^-1 <= b1_beta <= 18000 h^-1
- 30 h^-1 <= q_beta <= 1200 h^-1
- 30 h^-1 <= s_beta <= 1200 h^-1
- max[-x'(t)/x(t)] h^-1 <= r0_beta <= 5 h^-1
- 0.006 nM^-1 h^-1 <= k_beta <= 0.06 nM^-1 h^-1
- 0.006 nM^-1 h^-1 <= l_beta <= 0.06 nM^-1 h^-1
- 0.1 <= u_beta <= 1 nM
- 0 <= v_beta <= 1 nM
The meanings of parameters are described in the manuscript.

This code requires one input file "PER2_profile.txt". The input file is in
a tab-separated format and it includes the protein abundance profile
data for one oscillation period. The first column of the file has time and the second column
of the file has protein abundance data. "PER2_profile.txt" is from Jo, H.-H.,
Kim, Y.J., Kim, J.K. et al., "Waveforms of molecular oscillations reveal
circadian timekeeping mechanisms", Commun Biol 1, 207 (2018),
https://doi.org/10.1038/s42003-018-0217-1.

This code creates "model_PER2_result.csv" as its output file. The output file
contains:
- the randomly generated parameter values;
- status of the solution, "feasible" - "feasible" = 0 if the solution is
  biologically feasible, or "feasible" = 1 if it is biologically infeasible;
- proteosynthetic cost (in nM h^-1), "cost";
- alpha_D value of the solution, "alpha_D";
- similarity between simulated r(t) and empirical degradation-rate profile, "similarity".

In the "model#.py", there are 9 modules as follows:
- "read_PER2_original". This module reads PER2 protein profile data. 
- "rt_est". With [-x'(t)/x(t)] data and empirical protein degradation rate,
  this module generate estimated r(t) profile. Estimated r(t) profile is made
  by linearly interpolating known protein degradation rates and [-x'(t)/x(t)]
  values, which are lower limits of the protein degradation rates.
- "linear_fun". With a given slope and a point, this module generates a linear
  function and returns the linear function value of a given time point.
- "main". This module calculates [-x'(t)/x(t)] from the given PER2 protein
  profile data, randomly generates the model parameter values, and call
  "ode_solve" module to solve the protein degradation model for "num_of_trial"
  times.
- "ode_solve". With the given protein abundance data and randomly generated
  parameters, this module solves the system of ODEs. Then it calculates
  proteosynthetic cost (in nM h^-1) using the solution and similarity between simulated r(t) and empirical degradation-rate profile.
- "equation_Full". This module contains the system of ODEs.
- "similarity1". This module calculates similarity between two
  time series data.
- "findMaxMin". With a given profile, this module calculates the peak value
  and trough value.
- "Xprof". This module interpolates the given time series of protein profile
  data and returns protein abundance data at the given time "t". The peak value
  of the protein profile is normalized to 14nM.

In the code, num_of_trial = 1. Running "PER2_real.py" with num_of_trial = 1
takes less than one minute on a "normal desktop".


*** Contact information
This code was written by Junghun Chae. If you have any question,
please contact Junghun Chae via "wjdgnswkd612@gmail.com".
