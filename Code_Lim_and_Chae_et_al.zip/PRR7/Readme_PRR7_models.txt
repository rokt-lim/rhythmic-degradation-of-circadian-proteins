File name: model0.py, model1.py, model2.py, model3.py, model4.py

These python codes can be run on Windows 10, Linux or macOS. Python 3.5 or later
is required. The codes require the following Python packages:
- numpy,
- scipy,
- random.
Installing the required Python packages does not take long time (less than 10
minutes).

These codes randomly generate parameter values within the physiologically-relevant ranges
for the protein degradation models, solve the protein degradation models using
the given PRR7 protein abundance data with the following conditions:
- v = 0,
- z = 0,
- k=k_1=k_2=k_3=k_4,
and compute
- alpha_D,
- proteosynthetic costs,
- and similarity between simulated r(t) and empirical degradation-rate profile.

The parameter ranges are given as follows: 
- 180 nM^-1 h^-1 <= a0 <= 4800 nM^-1 h^-1
- 420 h^-1 <= a1 <= 18000 h^-1
- 180 h^-1 <= a2 <= 18000 h^-1
- 0.006 nM^-1 h^-1 <= k <= 0.06 nM^-1 h^-1
- 30 h^-1 <= q <= 1200 h^-1
- max[-x'(t)/x(t)] h^-1 <= r0 <= 5 h^-1
- 0.1 <= u <= 1 nM
- 30 <= y <= 300 nM
The meanings of parameters are described in the manuscript.

The numbers included in the file names mean the number of phosphorylation
events (i.e. model2.py solves protein degradation model n=2).

These codes require one input file "PRR7_profile.txt". The input file is in
a tab-separated format and it includes the protein abundance profile
data. The first column has the file is time (in h) and second column of the
file has protein abundance data. Each timepoint is separated by 0.05 h.
"PRR7_profile.txt" is made by repeating the PRR7 protein abundance profile
from Jo, H.-H., Kim, Y.J., Kim, J.K. et al., "Waveforms of molecular
oscillations reveal circadian timekeeping mechanisms", Commun Biol 1,
207 (2018), https://doi.org/10.1038/s42003-018-0217-1.

Each code creates "model#_result.csv" as its output and # in
"model#_result.csv" is the same as the number in the code file.
The output files contain:
- the randomly generated parameter values;
- status of the solution, "feasible" - "feasible" = 0 if the solution is
  biologically feasible, or "feasible" = 1 if it is biologically infeasible;
- proteosynthetic cost (in nM h^-1), "cost";
- alpha_D value of the solution, "alpha_D";
- similarity between simulated r(t) and empirical degradation-rate profile, "similarity".

The codes assume that "v(t)=0". Thus, the values of "x_H_ub(t)" are zeros in
the protein degradation model n=0, 1, 2, 3, and 4. The values of "b0", "b1",
and "s" are not required in the code. The values of "l_1", "l_2", "l_3", and
"l_4" are not required because "z(t)=0".

In the "model#.py", there are 9 modules as follows:
- "read_PRR7_original". This module reads PRR7 protein profile data.
- "rt_est". With [-x'(t)/x(t)] data and empirical protein degradation rate,
  this module generate estimated r(t) profile. Estimated r(t) profile is made
  by linearly interpolating known protein degradation rates and [-x'(t)/x(t)]
  values, which are lower limits of the protein degradation rates.
- "linear_fun". With a given slope and a point, this module generates a linear
  function and returns the linear function value of a given time point.
- "main". This module calculates [-x'(t)/x(t)] from the given PRR7 protein
  profile data, randomly generates the model parameter values, and call
  "ode_solve" module to solve the protein degradation model for "num_of_trial"
  times.
- "ode_solve". With the given protein abundance data and randomly generated
  parameters, this module solves the system of ODEs. Then it calculates
  proteosynthetic cost (in nM h^-1) using the solution and similarity 
between simulated r(t) and empirical degradation-rate profile.
- "equation_Full". This module contains the system of ODEs.
- "similarity1". This module calculates similarity between two
  time series data.
- "findMaxMin". With a given profile, this module calculates the peak value
  and trough value.
- "Xprof". This module interpolates the given time series of protein profile
  data and returns protein abundance data at the given time "t". The peak value
  of the protein profile is normalized to 3nM.

In the codes, num_of_trial = 1. Running "model0.py", "model1.py", "model2.py",
"model3.py", or "model4.py" with num_of_trial = 1 takes less than one minute on
a "normal desktop".


*** Contact information
This code was written by Junghun Chae. If you have any question,
please contact Junghun Chae via "wjdgnswkd612@gmail.com".
