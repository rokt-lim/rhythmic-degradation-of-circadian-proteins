# -*- coding: utf-8 -*-
"""
When a protein synthesis rate is given,
this code solves the protein degradation model with
the following conditions:
- # of phosphorylation events = 0,
- v(t) = 0.

@author: LIM Roktaek
@e-mail: rokt.lim@gmail.com
"""

####-- Modules

import sys
import pandas
import numpy
import copy
from scipy.integrate import solve_ivp

####-- END Modules

####-- Functions

###
def g_function(g_L,g_alpha,t_off,T_period,t_eval):
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t_eval-t_off))
    #-- return
    return g_t
###

###
def solution_feasibility(tag,D_t,R_t):
    D_t_R_t = D_t - R_t
    if numpy.min(D_t_R_t) >= 0.0:
        print(tag + ', feasible')
    else:
        print(tag + ', infeasible')
    #
    #-- return
    return 0
###

###
def solution_flag(X_coeff_inv,U_tau,x_sol,tag_e_0,tag_e_ub):
    n_v,_ = x_sol.shape
    #-- check variables, negative values
    neg_flag_check = []
    for ix in range(0,n_v):
        tmp = numpy.amin(x_sol[ix,:])
        if tmp < -1.0e-6:
            neg_flag_check.append('1')
        else:
            neg_flag_check.append('0')
        #
    #
    if '1' in neg_flag_check:
        pos_flag = 'fail'
    else:
        pos_flag = 'pass'
    #
    #-- compute u_t
    u_t = X_coeff_inv*U_tau - x_sol[tag_e_0,:] - x_sol[tag_e_ub,:]
    u_flag = 'pass'
    if numpy.amin(u_t) < 0.0:
        u_flag = 'fail'
    #
    return '|'.join([pos_flag,u_flag])
###

###-- ODE function: np = 0 without g_t
def model_np0_ODE(a0,a1,a2,r0,k,q,u_t,x,dx_tot_dt):
    dx_dt = numpy.zeros(x.shape)
    # dx_dt[0,:] = g_t - a0*u_t*x[0,:] + a1*x[1,:]
    dx_dt[1,:] = a0*u_t*x[0,:] - a1*x[1,:] - q*x[1,:]
    dx_dt[2,:] = q*x[1,:] + a0*u_t*x[3,:] - a2*x[2,:] - r0*x[2,:]
    dx_dt[3,:] = a2*x[2,:] - a0*u_t*x[3,:] - r0*x[3,:]
    #-- compute dx_dt[0,:] and g_t from dx_tot_dt
    dx_dt[0,:] = dx_tot_dt - numpy.sum(dx_dt[1:,:],axis=0)
    g_t = dx_dt[0,:] + a0*u_t*x[0,:] - a1*x[1,:]
    #-- return
    return dx_dt,g_t
###

###-- ODE function: np = 0 with g_t
def model_np0_ODE_dflt(a0,a1,a2,r0,k,q,g_t,u_t,x):
    dx_dt = numpy.zeros(x.shape)
    dx_dt[0,:] = g_t - a0*u_t*x[0,:] + a1*x[1,:]
    dx_dt[1,:] = a0*u_t*x[0,:] - a1*x[1,:] - q*x[1,:]
    dx_dt[2,:] = q*x[1,:] + a0*u_t*x[3,:] - a2*x[2,:] - r0*x[2,:]
    dx_dt[3,:] = a2*x[2,:] - a0*u_t*x[3,:] - r0*x[3,:]
    #-- return
    return dx_dt
###

###-- ODE function: np = 1 with g_t
def model_np1_ODE_dflt(a0,a1,a2,r0,k,q,g_t,u_t,y_t,x):
    dx_dt = numpy.zeros(x.shape)
    dx_dt[0,:] = g_t - k*y_t*x[0,:]
    dx_dt[1,:] = k*y_t*x[0,:] - a0*u_t*x[1,:] + a1*x[2,:]
    dx_dt[2,:] = a0*u_t*x[1,:] - a1*x[2,:] - q*x[2,:]
    dx_dt[3,:] = q*x[2,:] + a0*u_t*x[4,:] - a2*x[3,:] - r0*x[3,:]
    dx_dt[4,:] = a2*x[3,:] - a0*u_t*x[4,:] - r0*x[4,:]
    #-- return
    return dx_dt
###

###
def dX_dt_np1_given_G_np0(t,y,pv):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    #-- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- n = 0 with given x profile and different U_tau
    # x_e_0  = y[5]
    # x_e_ub = y[6]
    # x_0_ub = y[7]
    U_0 = pv[12]
    x_n = y[0] + y[1] + y[2] + y[3] + y[4] - (y[5] + y[6] + y[7])
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_0 - y[5] - y[6]
    dy_dt[5] = a0*u_t*x_n - a1*y[5] - q*y[5]
    dy_dt[6] = q*y[5] + a0*u_t*y[7] - a2*y[6] - r0*y[6]
    dy_dt[7] = a2*y[6] - a0*u_t*y[7] - r0*y[7]
    #-- dx_n_dt and g_t_n
    dx_n_dt = dy_dt[0] + dy_dt[1] + dy_dt[2] + dy_dt[3] + dy_dt[4] -\
        (dy_dt[5] + dy_dt[6] + dy_dt[7])
    g_t_n = dx_n_dt + a0*u_t*x_n - a1*y[5]
    #-- n = 0, with given g(t) (n = 0) and different U_tau
    # x_0    = y[8]
    # x_e_0  = y[9]
    # x_e_ub = y[10]
    # x_0_ub = y[11]
    U_new = pv[14]
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_new - y[9] - y[10]
    dy_dt[8] = g_t_n - a0*u_t*y[8] + a1*y[9]
    dy_dt[9] = a0*u_t*y[8] - a1*y[9] - q*y[9]
    dy_dt[10] = q*y[9] + a0*u_t*y[11] - a2*y[10] - r0*y[10]
    dy_dt[11] = a2*y[10] - a0*u_t*y[11] - r0*y[11]
    #-- return
    return dy_dt
###

###
def simulation_given_g(model_p_name,U_new):
    #-- read model parameters
    df_p = pandas.read_csv(model_p_name)
    a0 = df_p.loc[0,'a0']
    a1 = df_p.loc[0,'a1']
    a2 = df_p.loc[0,'a2']
    r0 = df_p.loc[0,'r0']
    k  = df_p.loc[0,'k']
    q  = df_p.loc[0,'q']
    U_tau = df_p.loc[0,'U']
    Y_tau = df_p.loc[0,'Y']
    U_0 = df_p.loc[0,'U_0']
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    #-- read parameters for g(t)
    g_L = df_p.loc[0,'g_L']
    g_alpha = df_p.loc[0,'g_alpha']
    t_off = df_p.loc[0,'t_off']
    #-- parameters for ivp_solver
    T_period = 24.0
    t_start  = 0.0
    t_end    = 20.0*T_period
    dt       = 0.05
    tp = numpy.linspace(t_start,t_end,int((t_end-t_start)/dt) + 1)
    x_init = numpy.zeros((5,))
    x_init[0] = 1.0
    y_0 = numpy.concatenate((x_init,numpy.zeros(7,)))
    y_0[8] = 1.0
    #-- read U values
    pv = [a0,a1,a2,r0,k,q,T_period,g_L,g_alpha,t_off,U_tau,Y_tau,U_0,0.0,U_new]
    sol = solve_ivp(fun=lambda t,y : dX_dt_np1_given_G_np0(t,y,pv),
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    #-- solution for n = 1
    x_sol = copy.deepcopy(sol.y[0:5,:])
    x_tot = numpy.sum(x_sol,axis=0)
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - x_sol[2,:] - x_sol[3,:]
    y_t = r0*Y_tau/k
    g_t = g_function(g_L,g_alpha,t_off,T_period,sol.t)
    dx_dt = model_np1_ODE_dflt(a0,a1,a2,r0,k,q,g_t,u_t,y_t,x_sol)
    dx_tot_dt = numpy.sum(dx_dt,axis=0)
    R_t = (-1.0/r0)*numpy.divide(dx_tot_dt,x_tot)
    D_t = numpy.divide(x_sol[3,:] + x_sol[4,:],x_tot)
    df_given_x = pandas.DataFrame({ 't'      : sol.t,
                                    'x'      : x_tot,
                                    'dxdt'   : dx_tot_dt,
                                    'R'      : R_t,
                                    'x_0'    : x_sol[0,:],
                                    'x_p'    : x_sol[1,:],
                                    'x_E_0'  : x_sol[2,:],
                                    'x_E_ub' : x_sol[3,:],
                                    'x_0_ub' : x_sol[4,:] })
    df_given_x.to_csv('given_g_x_n_1.csv',index=False)
    flag = solution_flag(X_coeff_inv,U_tau,x_sol,2,3)
    print('solution using model parameters, flag:',flag)
    solution_feasibility('solution using model parameters',D_t,R_t)
    #-- solution for n = 0 using U_0
    x_sol_X = numpy.zeros((4,len(tp)))
    x_sol_X[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_e_0
    x_sol_X[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_e_ub
    x_sol_X[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_0_ub
    x_sol_X[0,:] = x_tot - numpy.sum(x_sol_X[1:,:],axis=0)
    u_t = X_coeff_inv*U_0 - x_sol_X[1,:] - x_sol_X[2,:]
    dx_dt,g_t = model_np0_ODE(a0,a1,a2,r0,k,q,u_t,x_sol_X,dx_tot_dt)
    D_t = numpy.divide(x_sol_X[2,:] + x_sol_X[3,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_sol_X[0,:],
                                'x_E_0'  : x_sol_X[1,:],
                                'x_E_ub' : x_sol_X[2,:],
                                'x_0_ub' : x_sol_X[3,:],
                                'g'      : g_t,
                                'D'      : D_t })
    df_sol.to_csv('given_g_protein_synthesis_rate_U_0.csv',index=False)
    flag_X = solution_flag(X_coeff_inv,U_0,x_sol_X,1,2)
    print('\nn=0 and U_0, flag:',flag_X)
    solution_feasibility('n=0 and U_0',D_t,R_t)
    #-- solution for n = 0 uisng g_t (n = 0) and U_new
    x_sol_G = copy.deepcopy(sol.y[8:,:])
    x_sol_G_tot = numpy.sum(x_sol_G,axis=0)
    u_t = X_coeff_inv*U_new - x_sol_G[1,:] - x_sol_G[2,:]
    dx_dt_G = model_np0_ODE_dflt(a0,a1,a2,r0,k,q,g_t,u_t,x_sol_G)
    dx_tot_dt_G = numpy.sum(dx_dt_G,axis=0)
    R_t_G = (-1.0/r0)*numpy.divide(dx_tot_dt_G,x_sol_G_tot)
    D_t_G = numpy.divide(x_sol_G[2,:] + x_sol_G[3,:],x_sol_G_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_sol_G[0,:],
                                'x_E_0'  : x_sol_G[1,:],
                                'x_E_ub' : x_sol_G[2,:],
                                'x_0_ub' : x_sol_G[3,:],
                                'dxdt'   : dx_tot_dt_G,
                                'R'      : R_t_G,
                                'D'      : D_t_G })
    df_sol.to_csv('given_g_solution_U_new.csv',index=False)
    flag_G = solution_flag(X_coeff_inv,U_new,x_sol_G,1,2)
    print('\nn=0 and U_new, flag:',flag_G)
    solution_feasibility('n=0 and U_new',D_t_G,R_t_G)
    #-- return
    return 0
###

####-- END Functions

####-- Main script

simulation_given_g('given_g_model_parameter_n1.csv',0.3)

####-- END ---####
