"""
code  written by junghun Chae

If you have any question, please email to the following address.
wjdgnswkd612@gmail.com

Readme
"freex" variable refers to "x_0(t)".
parameter 'c' refers to 'r0'.
"R" refers [x'(t)/x(t)] with dimension of 1/r0.
"Rmax" refers maximum of R with dimension of 1/r0.
substrate_sum in equation_Full function is "total protein abundance - x_0(t)".
alphaD is equal to alpha_r(t).
"""
#-*-coding: utf-8 -*-

import numpy as np
from scipy.interpolate import interp1d
import scipy.interpolate as inp
from scipy.integrate import trapz
from scipy.integrate import solve_ivp
import random as rd

def read_protein_data():
    ## read PER2 protein profile data
    ## input : none
    ## ouput :
    ## t_P : time points of protien profile data.
    ## x_P : protein profile time series data.

    file_P = open("protein_profile.txt",'r')
    data_P = file_P.read()
    file_P.close()

    data_P = data_P.split("\n")
    data_P.pop()

    Protein_data = []
    for i in data_P:
        Protein_data.append(i.split("\t"))

    t_P = []
    x_P = []
    R_P = []
    Protein_data = np.array(Protein_data)

    for i in Protein_data[:,0]:
        t_P.append(float(i))
    for i in Protein_data[:,1]:
        x_P.append(float(i))

    ## repetiting PER2 data for 5 times to make oscillation
    t_rep = []
    x_rep = []
    for i in range(10):
        for jidx, j in enumerate(t_P):
            t_rep.append(j-24*(2-i))
            x_rep.append(x_P[jidx])

    return (t_rep, x_rep)

def equation_Full(t, y, para1, para2, para3, para4, Xprof):   
    ## The main equations of the ode system.
    ## input :
    ## y : array of protein substrate component at time t.
    ## para1 : parameters related to ubiquitination for 1 times phosphorylated substrate.
    ## para2 : parameters related to ubiquitination for 2 times phosphorylated substrate.
    ## para3 : parameters related to ubiquitination for 3 times phosphorylated substrate.
    ## para4 : parameters related to ubiquitination for 4 times phosphorylated substrate.
    ## Xprof : Xprofile data
    ## t : time
    ## para : parameters
    ## return :
    ## dxvardt = dy/dt

    
    a10=para1[0]
    a11=para1[1]
    a12=para1[2]
    b10=para1[3]
    b11=para1[4]
    k1=para1[5]
    q1=para1[7]
    c1=para1[10]
    u1=para1[13]
    yy=para1[15]

    a20=para2[0]
    a21=para2[1]
    a22=para2[2]
    b20=para2[3]
    b21=para2[4]
    k2=para2[5]
    q2=para2[7]
    c2=para2[10]
    u2=para2[13]

    a30=para3[0]
    a31=para3[1]
    a32=para3[2]
    b30=para3[3]
    b31=para3[4]
    k3=para3[5]
    q3=para3[7]
    c3=para3[10]
    u3=para3[13]

    a40=para4[0]
    a41=para4[1]
    a42=para4[2]
    b40=para4[3]
    b41=para4[4]
    k4=para4[5]
    q4=para4[7]
    c4=para4[10]
    u4=para4[13]
    
    xp1=y[0]; xp2=y[1]; xp3=y[2]; xp4=y[3]

    xeo1=y[4]; xeub1=y[5]; xoub1=y[6]

    xeo2=y[7]; xeub2=y[8]; xoub2=y[9]

    xeo3=y[10]; xeub3=y[11]; xoub3=y[12]

    xeo4=y[13]; xeub4=y[14]; xoub4=y[15]
    
    u1=u1-xeo1-xeub1
    u2=u2-xeo2-xeub2
    u3=u3-xeo3-xeub3
    u4=u4-xeo4-xeub4

    Xtot = Xprof(t)

    tot_d1=0
    for i in range(16):
        tot_d1=tot_d1+y[i]
    freex= Xtot - tot_d1
    

    dxp1dt=-k2*yy*xp1+k1*yy*freex-a10*u1*xp1+a11*xeo1

    dxeo1dt=a10*u1*xp1-a11*xeo1-q1*xeo1

    dxeub1dt=q1*xeo1+a10*u1*xoub1-a12*xeub1-c1*xeub1

    dxoub1dt=a12*xeub1-a10*u1*xoub1-c1*xoub1
    
    #2nd
    dxp2dt=-k3*yy*xp2+k2*yy*xp1-a20*u2*xp2+a21*xeo2

    dxeo2dt=a20*u2*xp2-a21*xeo2-q2*xeo2

    dxeub2dt=q2*xeo2+a20*u2*xoub2-a22*xeub2-c2*xeub2

    dxoub2dt=a22*xeub2-a20*u2*xoub2-c2*xoub2
    
    #3rd
    dxp3dt=-k4*yy*xp3+k3*yy*xp2-a30*u3*xp3+a31*xeo3

    dxeo3dt=a30*u3*xp3-a31*xeo3-q3*xeo3

    dxeub3dt=q3*xeo3+a30*u3*xoub3-a32*xeub3-c3*xeub3

    dxoub3dt=a32*xeub3-a30*u3*xoub3-c3*xoub3
    
    #4th
    dxp4dt=k4*yy*xp3-a40*u4*xp4+a41*xeo4

    dxeo4dt=a40*u4*xp4-a41*xeo4-q4*xeo4

    dxeub4dt=q4*xeo4+a40*u4*xoub4-a42*xeub4-c4*xeub4

    dxoub4dt=a42*xeub4-a40*u4*xoub4-c4*xoub4
    
    return [dxp1dt, dxp2dt, dxp3dt, dxp4dt,\
            dxeo1dt,dxeub1dt,dxoub1dt,\
            dxeo2dt,dxeub2dt,dxoub2dt,\
            dxeo3dt,dxeub3dt,dxoub3dt,\
            dxeo4dt,dxeub4dt,dxoub4dt]

def findMaxMin(x, t, howlong, DPeriod = 24, NdayDelete = 3):
    ## find peak and trough value of give give profile.
    ## input :
    ## x : time series data of given profile
    ## t : array of time points for profile x.
    ## howlong : the total lengh of the time series.
    ## DPeriod : the oscillation Period.  defult is 24 hours
    ## NdayDelete : time it takes to begin oscillation.
    ## it deletes initial 3 days of time series for default.
    ## output :
    ## array of peak and trough value

    length = len(t)
    aDay = int(length/howlong*DPeriod)
    Days = int(howlong/DPeriod)-1
    mini = []
    maxi = []

    for i in range(NdayDelete,Days):
        maxi.append(-1000)
        mini.append(1000)
        for idx in range(aDay):
            if maxi[i-NdayDelete]<x[i*aDay+idx]:
                maxi[i-NdayDelete] = x[i*aDay+idx]

            if mini[i-NdayDelete]>x[i*aDay+idx]:
                mini[i-NdayDelete] = x[i*aDay+idx]

    avgmini = 0
    avgmaxi = 0

    for i in range(Days-NdayDelete):
        avgmaxi = avgmaxi+maxi[i]/(Days-NdayDelete)
        avgmini = avgmini+mini[i]/(Days-NdayDelete)
    return [avgmaxi,avgmini]

def ode_solve(para_list, Xmax, Xmin, Rmax, R, Xtot, dt, t, Xprof):
    ## solve ode and write file
    ##
    ## input :
    ## para : parameters
    ## Xmax : maximum value of x profile
    ## Xmin : minimum value of x profile
    ## Rmax : maximum value of R
    ## R    : time series of R ([x'(t)/x(t)] it has dimension of 1/c)
    ## Xtot : x protein profile
    ## dt   : minimum time step
    ## t    : evaluating time points
    ##
    ## output :
    ## there is no function return.
    ## this function writes files
    ## it writes following values
    ## parameters   : parameters to generate the profile
    ## feasible     : 0 if the profile satisfies feasible condition, 1 if not.
    ## cost         : time average of total proten synthesis during one period
    ## alphaD   : alpha value of r(t) profile


    xnew=solve_ivp(fun=lambda  y, t: equation_Full(y, t, para_list[0],para_list[1],para_list[2],para_list[3], Xprof),\
                        y0=[0 for i in range(16)], t_eval=t, t_span=[0, t[-1]], method="LSODA", atol=1e-5, rtol=1e-5)

    t = xnew.t

    subtrate_sum = 0
    for i in range(16):
        subtrate_sum = subtrate_sum+xnew.y[i]
    freex = Xtot - subtrate_sum

    t=xnew.t

    xp1=xnew.y[0]; xp2=xnew.y[1]; xp3=xnew.y[2]; xp4=xnew.y[3]

    xeo1=xnew.y[4]; xeub1=xnew.y[5]; xoub1=xnew.y[6]

    xeo2=xnew.y[7]; xeub2=xnew.y[8]; xoub2=xnew.y[9]

    xeo3=xnew.y[10]; xeub3=xnew.y[11]; xoub3=xnew.y[12]

    xeo4=xnew.y[13]; xeub4=xnew.y[14]; xoub4=xnew.y[15]

    rt_sim = (para_list[0][10]*(xeub1+xoub1)+para_list[1][10]*(xeub2+xoub2)+\
        para_list[2][10]*(xeub3+xoub3)+para_list[3][10]*(xeub4+xoub4))/Xtot

    rt_max, rt_min = findMaxMin(rt_sim, t, 24*5, 24, NdayDelete = 2)
    alphaD = 1 - rt_min / rt_max

    feasible = 0

    u1 = para_list[0][13]
    u2 = para_list[1][13]
    u3 = para_list[2][13]
    u4 = para_list[3][13]

    u1 = u1 - xeub1 - xeo1
    u2 = u2 - xeub2 - xeo2
    u3 = u3 - xeub3 - xeo3
    u4 = u4 - xeub4 - xeo4
    
    if u1.min() < 0 :
        feasible = 1 
    if u2.min() < 0 :
        feasible = 1 
    if u3.min() < 0 :
        feasible = 1 
    if u4.min() < 0 :
        feasible = 1 

    #calculating g profile
    g=(rt_sim-R)*Xtot

    xmin = 0
    for i in range(16):
        if xnew.y[i].min()<0:
            xmin = xnew.y[i].min()
            feasible = 1

    DR_min = (rt_sim-R).min()
    if DR_min < 0:
        feasible = 1

    if freex.min() < 0:
        feasible = 1

    gmin = g.min()

    if gmin < 0 :
        feasible = 1

    cost = trapz(g[int(72/dt):int(96/dt)], xnew.t[int(72/dt):int(96/dt)])/24

    return  [para_list, feasible, cost, alphaD]

def main():
    t, x = read_protein_data()
    
    P_inp = interp1d(t, x, kind = "cubic")

    Period = 24
    dt=0.05
    end_FullEquation = 5*Period

    t_eval = np.linspace(0,end_FullEquation, int(end_FullEquation/dt)+1)

    Xtot = []
    for i in t_eval:
        Xtot.append(P_inp(i))

    ## R with dt=0.05
    R = [-0.1,-0.1]
    for i in range(2,len(t_eval)-2):
        h = t_eval[i+1]-t_eval[i]
        R.append( -1/(Xtot[i])*(-Xtot[i+2]+8*Xtot[i+1]-8*Xtot[i-1]+Xtot[i-2])/12/h  )
    R.append(R[-1])
    R.append(R[-1])

    ## Xprofile interpolation
    def Xprof(t):
        return P_inp(t)

    Rmax = max(R)
    Xmax = max(Xtot)
    Xmin = min(Xtot)

    file = open("./model_multiple_pathway_result.csv",'w')
    file.write("a10,a11,a12,k1,q1,r10,u1,\
        a20,a21,a22,k2,q2,r20,u2,\
        a30,a31,a32,k3,q3,r30,u3,\
        a40,a41,a42,k4,q4,r40,u4,\
        y,feasible,cost,alpha_D\n")
    file.close()

    num_of_trial=1
    for i in range(num_of_trial):
        k_list = [0 for i in range(4)]
        ll_list = [0 for i in range(4)]
        for i in range(4):
            k_list[i] = rd.uniform(0.006,0.06)
            ll_list[i] = rd.uniform(0.006,0.06)

        y = rd.uniform(30,300)

        para_list=[[0 for i in range(17)] for i in range(6)]
        for para_num in range(4):
            a0=para_list[para_num][0]=rd.uniform(180,4800)
            a1=para_list[para_num][1]=rd.uniform(420,18000)
            a2=para_list[para_num][2]=rd.uniform(180,18000)
            b0=para_list[para_num][3]=rd.uniform(180,4800)
            b1=para_list[para_num][4]=rd.uniform(180,18000)
            para_list[para_num][5]=k_list[para_num]

            q=para_list[para_num][7]=rd.uniform(30,1200)
            s=para_list[para_num][8]=rd.uniform(30,1200)

            c=para_list[para_num][10]=rd.uniform(Rmax, 5)

            para_list[para_num][13]=rd.uniform(0.1,1)
            para_list[para_num][15]=y

        para, feasible, cost, alphaD = ode_solve(para_list, Xmax, Xmin, Rmax, R, Xtot, dt, t_eval, Xprof)

        ## writing file
        file = open("./model_multiple_pathway_result.csv",'a')

        for para_num in range(4):
            a0=para_list[para_num][0]
            a1=para_list[para_num][1]
            a2=para_list[para_num][2]
            b0=para_list[para_num][3]
            b1=para_list[para_num][4]

            k=k_list[para_num]
            ll=ll_list[para_num]

            q=para_list[para_num][7]
            s=para_list[para_num][8]
            c=para_list[para_num][10]

            u=para_list[para_num][13]
            v=para_list[para_num][14]

            file.write(str(a0)+",")
            file.write(str(a1)+",")
            file.write(str(a2)+",")
            file.write(str(k)+",")
            file.write(str(q)+",")
            file.write(str(c)+",")
            file.write(str(u)+",")
        file.write(str(y)+",")

        file.write(str(feasible)+",")
        file.write(str(cost)+",")
        file.write(str(alphaD)+",")
        file.write("\n")
        file.close()

main()
