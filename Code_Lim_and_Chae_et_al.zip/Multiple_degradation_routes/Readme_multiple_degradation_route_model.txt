﻿File name: branched_pathway.py

This python code can be run on Windows 10, Linux or macOS. Python 3.5 or later
is required. The code requires the following Python packages:
- numpy,
- scipy,
- random.
Installing the required Python packages does not take long time (less than 10
minutes).

This code randomly generates parameter values within the physiologically-relevant ranges
for the models with multiple degradation pathways, solves the model using a given
protein abundance data with the following conditions:
- v_i = 0,
- z = 0,
and computes alpha_D and proteosynthetic costs.

The parameter ranges are given as follows: 
- 180 nM^-1 h^-1 <= a0_1,a0_2,a0_3,a0_4 <= 4800 nM^-1 h^-1
- 420 h^-1 <= a1_1,a1_1,a1_1,a1_1 <= 18000 h^-1
- 180 h^-1 <= a2_1,a2_1,a2_1,a2_1 <= 18000 h^-1
- max[-x'(t)/x(t)] h^-1 <= r0_1,r0_2,r0_3,r0_4 <= 5 h^-1
- 0.006 nM^-1 h^-1 <= k_1,k_2,k_3,k_4 <= 0.06 nM^-1 h^-1
- 30 h^-1 <= q_0,q_1,q_2,q_3,q_4 <= 1200 h^-1
- 0.1 <= u_1,u_2,u_3,u_4 <= 1 nM
- 30 <= y <= 300 nM
The meanings of parameters are described in the manuscript.

The code assumes that v_i = 0. Thus, the values of "x_H_ub_i(t)” are zeros
in these models for i=1,2,3,4. The values of "b0_i", "b1_i",
and "s_i" for i=1,2,3,4, are not required in the code. The values of
parameters "l_i" for i=1,2,3,4 are not required because z = 0.

This code requires one input file "protein_profile.txt". The input file is in
a tab-separated format and it includes the protein abundance profile
data for one oscillation period. The first column of the file has time and the second column of
the file is protein abundance data. Each time point is separated by 0.05 hours.

This code creates "model_multiplepathway_result.csv" as its output file.
The output file contains:
- the randomly generated parameter values;
- status of the solution, "feasible" - "feasible" = 0 if the solution is
  biologically feasible, or "feasible" = 1 if it is biologically infeasible;
- proteosynthetic cost (in nM h^-1), "cost";
- alpha_D value of the solution, "alpha_D".

In the "branched_pathway.py", there are 6 modules as follows:
- "read_protein_data". This module reads protein profile data.
- "equation_Full". This module contains the system of ODEs.
- "findMaxMin". With a given profile, this module calculates the peak value
  and trough value.
- "Xprof". This module interpolates the given time series of protein profile
  data and returns protein abundance data at the given time "t".
- "main". This module calculates [-x'(t)/x(t)] from the given protein abundance
  data, randomly generates the model parameter values, and call "ode_solve"
  module to solve the protein degradation model for "num_of_trial" times.
- "ode_solve". With the given protein abundance data and randomly generated
  parameters, this module solves the system of ODEs. Then it calculates
  proteosynthetic cost (in nM h^-1) using the solution and similarity values
  between estimated r(t) profile and r(t) profile computed by using the
  solution.

In the code, num_of_trial = 1. Running "branched_pathway.py" with
num_of_trial = 1 takes less than one minute on a "normal desktop".


*** Contact information
This code was written by Junghun Chae. If you have any question,
please contact Junghun Chae via "wjdgnswkd612@gmail.com".
