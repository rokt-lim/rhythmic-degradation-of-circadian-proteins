"""
code  written by junghun Chae

If you have any question, please email to the following address.
wjdgnswkd612@gmail.com

Readme
"freex" variable refers to "x_0(t)".
parameter 'c' refers to 'r0'.
"R" refers [x'(t)/x(t)] with dimension of 1/r0.
"Rmax" refers maximum of R with dimension of 1/r0.
substrate_sum in equation_Full function is "total protein abundance - x_0(t)".
alphaD is equal to alpha_r(t).
"""
#-*-coding: utf-8 -*-

import numpy as np
import scipy.interpolate as inp
from scipy.interpolate import interp1d
from scipy.integrate import trapz
from scipy.integrate import solve_ivp
import random as rd

def similarity1(x1, x2, t):
    ## similarity 1 calculation.
    ## input :
    ## x1, x2 : two profile(time series data) to calculate the similarity1 index.
    ## t : time point of the x1 and x2 time series data.
    ##
    ## output :
    ## simiarity1 index between x1 and x2 profile.

    max_fun = []
    min_fun = []
    for idx, i in enumerate(t):
        max_fun.append(max(x1[idx], x2[idx]))
        min_fun.append(min(x1[idx], x2[idx]))
    max_area = trapz(max_fun,t)
    min_area = trapz(min_fun,t)

    return min_area/max_area

def linear_fun(a, c, x):
    ## calculate linear function and return function value of given x.
    ## input :
    ## a : tangent of the linear function
    ## c : array of one point on the line
    ## c[0] : x position of the point
    ## c[1] : y position of the point
    ## x : x position of where you want to estimate the function value
    ## output :
    ## function value of the given x position x

    return a*(x-c[0])+c[1]

def read_PRR7_original():
    ## read PRR7 protein profile data
    ## input : none
    ## ouput :
    ## t_P7 : time points of PRR7 protien profile data.
    ## x_P7 : PRR7 protein profile time series data.

    file_P7=open("PRR7_profile.txt",'r')
    data_P7=file_P7.read()
    file_P7.close()

    data_P7=data_P7.split("\n")
    data_P7.pop()

    Prr7_data=[]
    for i in data_P7:
        Prr7_data.append(i.split("\t"))
    Prr7_data=np.array(Prr7_data)

    t_P7=[]
    x_P7=[]
    for i in Prr7_data[:,0]:
        t_P7.append(float(i))
    for i in Prr7_data[:,1]:
        x_P7.append(float(i))

    return (t_P7, x_P7)

def rt_est(t, R, P7_expt, P7_expD, t_eval):
    ## function that generates interpolation fucntion of estimated r(t).
    ## input :
    ## R : array of R (-1/x*dx/dt)(it has dimension of 1/c).
    ## t : array of time points for R
    ## P7_expt : experimentally measured time points of r(t)
    ## P7_expD : experimentally measured r(t).
    ## t_eval : array of time points for interpolation
    ## output :
    ## inp_rt_est : interpolation function that returns r(t) estimated value at given time point t.

    R7_inp = interp1d(t, R, kind = "cubic")
    alist=np.linspace(0.2,0.1,1000)
    time_range=np.linspace(42,48, 10000)

    R7_search=[]
    for i in time_range:
        R7_search.append(R7_inp(i))
    a7_min=0
    t7_met=0


    for i in alist:
        lin=[]

        for j in time_range:
            lin.append(linear_fun(i, [P7_expt[-1], P7_expD[-1]], j))
        dif=(np.array(lin)-np.array(R7_search))

        if dif.min()<0:
            a7_min=i
            t7_met=time_range[ int(np.where(dif==dif.min())[0]) ]
            break


    D7_est_inp=interp1d(P7_expt, P7_expD, kind="linear")


    maxT=0
    for idx, i in enumerate(R):
        if i > P7_expD[0]:
            maxT=t[idx]
        if t[idx] > 30:
            break
    maxT += 24
    t_range=np.linspace(24,48,int(24/0.01)+1)


    D7_t_cubic=[P7_expt[0]-0.31+(i*0.01) for i in range(1,31)]+P7_expt+[t7_met]
    D7_est_cubic=[P7_expD[0] for i in range(30)]+P7_expD+[linear_fun(a7_min, [P7_expt[-1], P7_expD[-1]], t7_met)]

    R7_2_t=[]

    for tidx, t in enumerate(t_range):
        R7_2_t.append(t)
        if t>t7_met and t <maxT:
            D7_t_cubic.append(t)
            D7_est_cubic.append(R7_inp(t))



    for i in range(1,30):
        D7_t_cubic.append(maxT+0.01*i)
        D7_est_cubic.append(P7_expD[0])

    D7_t_cubic_full=[]
    D7_est_cubic_full=[]
    for i in range(10):
        for jidx, j in enumerate(D7_t_cubic):
            D7_t_cubic_full.append(j-24*(2-i))
            D7_est_cubic_full.append(D7_est_cubic[jidx])

    inp_rt_est = inp.interp1d(D7_t_cubic_full, D7_est_cubic_full, kind="linear")

    return  inp_rt_est

def equation_Full(y, t, para, Xprof):
    ## The main equations of the ode system.
    ## input :
    ## y : array of protein substrate component at time t.
    ## y[0] : xe0 component
    ## y[1] : xeub component
    ## y[2] : xoub component
    ## t : time
    ## para : parameters

    dxvardt = np.zeros(4)

    a0 = para[0]
    a1 = para[1]
    a2 = para[2]
    b0 = para[3]
    b1 = para[4]
    K = para[5]
    l = para[6]
    q = para[7]
    s = para[8]
    c = para[10]
    L = para[11]
    P = para[12]
    U = para[13]
    V = para[14]
    Y = para[15]
    Z = para[16]

    substrate_sum=0
    for i in range(4):
        substrate_sum = substrate_sum + y[i]
    freex = Xprof(t) - substrate_sum

    xeo = y[0]; xeub = y[1]; xoub = y[2]; xhub = y[3]

    coef_u = a0/c*q/(a1+q)
    coef_v = b0/c*(c+s)/(b1+c+s)


    u = U/coef_u - xeo - xeub
    v = V/coef_v - xhub

    dxvardt[0] = a0*u*freex - a1*xeo - q*xeo

    dxvardt[1] = q*xeo + a0*u*xoub - a2*xeub - c*xeub

    dxvardt[2] = a2*xeub - a0*u*xoub - c*xoub + b1*xhub - b0*v*xoub

    dxvardt[3]= -b1*xhub + b0*v*xoub - s*xhub - c*xhub

    return dxvardt

def findMaxMin(x, t, howlong, DPeriod = 24, NdayDelete = 3):
    ## find peak and trough value of give give profile.
    ## input :
    ## x : time series data of given profile
    ## t : array of time points for profile x.
    ## howlong : the total lengh of the time series.
    ## DPeriod : the oscillation Period.  defult is 24 hours
    ## NdayDelete : time it takes to begin oscillation.
    ## it deletes initial 3 days of time series for default.
    ## output :
    ## array of peak and trough value

    length = len(t)
    aDay = int(length/howlong*DPeriod)
    Days = int(howlong/DPeriod)-1
    mini = []
    maxi = []

    for i in range(NdayDelete,Days):
        maxi.append(-1000)
        mini.append(1000)
        for idx in range(aDay):
            if maxi[i-NdayDelete]<x[i*aDay+idx]:
                maxi[i-NdayDelete] = x[i*aDay+idx]

            if mini[i-NdayDelete]>x[i*aDay+idx]:
                mini[i-NdayDelete] = x[i*aDay+idx]

    avgmini = 0
    avgmaxi = 0

    for i in range(Days-NdayDelete):
        avgmaxi = avgmaxi+maxi[i]/(Days-NdayDelete)
        avgmini = avgmini+mini[i]/(Days-NdayDelete)
    return [avgmaxi,avgmini]

def ode_solve(para, Xmax, Xmin, Rmax, R, Xtot, dt, t, rt_est_PRR7, Xprof):
    ## solve ode and write file
    ##
    ## input :
    ## para : parameters
    ## Xmax : maximum value of x profile
    ## Xmin : minimum value of x profile
    ## Rmax : maximum value of R
    ## R    : time series of R ([x'(t)/x(t)] it has dimension of 1/c)
    ## Xtot : x protein profile
    ## dt   : minimum time step
    ## t    : evaluating time points
    ##
    ## output :
    ## there is no function return.
    ## this function writes files
    ## it writes following values
    ## parameters   : parameters to generate the profile
    ## feasible     : 0 if the profile satisfies feasible condition, 1 if not.
    ## cost         : time average of total proten synthesis during one period
    ## alphaD       : alpha value of r(t) profile
    ## sim          : similarity value of r(t) simulation compared with r(t) estimation


    xnew = solve_ivp(fun = lambda  t,y: equation_Full(y, t,  para, Xprof),\
                    y0 = [0 for i in range(4)], t_eval = t, t_span = [0, t[-1]], method = "LSODA", rtol = 1e-5 , atol = 1e-5)

    t = xnew.t
    xeo = xnew.y[0]; xeub = xnew.y[1]; xoub = xnew.y[2]; xhub=xnew.y[3]

    subtrate_sum = 0
    for i in range(4):
        subtrate_sum = subtrate_sum+xnew.y[i]
    freex = Xtot-subtrate_sum

    a0 = para[0]
    a1 = para[1]
    a2 = para[2]
    b0 = para[3]
    b1 = para[4]
    k = para[5]
    l = para[6]
    q = para[7]
    s = para[8]
    c = para[10]
    L = para[11]
    P = para[12]
    U = para[13]
    V = para[14]
    Y = para[15]
    Z = para[16]

    #r(t) profile made by this simulation
    rt_sim = (xeub + xoub+ xhub) / Xtot * c
    rt_max, rt_min = findMaxMin(rt_sim, t, 24*5, 24, NdayDelete = 2)
    alphaD = 1 - rt_min / rt_max

    feasible = 0

    coef_u = a0/c*q/(a1+q)
    coef_v = b0/c*(c+s)/(b1+c+s)

    u = U/coef_u
    v = V/coef_v

    freeu = u - xeo - xeub
    freev = v - xhub

    #calculating g profile
    g = []
    g.append(0.1)
    g.append(0.1)
    fac = 1
    for i in range(2, len(t)-2):
        dt = t[i+1]-t[i]
        g.append((( -freex[i+2] + 8 * freex[i+1] - 8 * freex[i-1] \
                    + freex[i-2] ) / 12 / dt + a0 * freeu[i] * freex[i] - a1 * xeo[i] - s * xhub[i]))
    g.append(g[-1])
    g.append(g[-1])
    g = np.array(g)

    xmin = 0
    for i in range(4):
        if xnew.y[i].min()<0:
            xmin = xnew.y[i].min()
            feasible = 1

    DR_min = (rt_sim-R).min()
    if DR_min < 0:
        feasible = 1

    if freex.min() < 0:
        feasible = 1

    if freeu.min() < 0:
        feasible = 1

    if freev.min() < 0:
        feasible = 1

    gmin = g.min()

    if gmin < 0 :
        feasible = 1

    sim = similarity1(rt_sim[int(72/dt):int(96/dt)], rt_est_PRR7[int(72/dt):int(96/dt)], xnew.t[int(72/dt):int(96/dt)])
    cost = trapz(g[int(72/dt):int(96/dt)], xnew.t[int(72/dt):int(96/dt)])/24
    if feasible ==0 :
        print(cost)

    return  [para, feasible, cost, alphaD, sim]

def main():
    ##PRR7 experimental t, r(t) values
    P7_expt=[28, 36, 42]
    P7_expD=[0.089169, 0.341079, 0.446286]

    t_P7, x_P7=read_PRR7_original()

    ## interpolation of PRR7 protein data.
    ## t_eval : time points to use.
    ## time step is 0.01 hour.
    P7_inp=interp1d(t_P7, x_P7, kind="cubic")
    t_eval = np.linspace(0,48,int(48/0.01)+1)

    x_inp = []
    for i in t_eval:
        x_inp.append(P7_inp(i))

    ## R with dt=0.01
    R = [0,0]
    for i in range(2,len(t_eval)-2):
        h = t_eval[i+1]-t_eval[i]
        R.append( -1/(x_inp[i])*(-x_inp[i+2]+8*x_inp[i+1]-8*x_inp[i-1]+x_inp[i-2])/12/h  )
    R.append(R[-1])
    R.append(R[-1])

    inp_est_rt = rt_est(t_eval,R, P7_expt, P7_expD, t_eval)

    rt_est_PRR7 = []
    dt = 0.05

    t_eval2 = np.linspace(0,24*5, int(24*5/dt)+1)

    for j in t_eval2:
        rt_est_PRR7.append(inp_est_rt(j))

    PRR7_interpolation = interp1d(t_P7, x_P7, kind = 'cubic')

    Period = 24
    big = 0
    end_FullEquation = 5*Period

    ## maximum timestep
    dt = 0.05

    ## evaluating timepoint
    t = np.linspace(0,end_FullEquation,int(end_FullEquation/dt)+1)

    max_x=max(x_P7)
    ## Xprofile interpolation
    ## maximum value of the Protein abundance is 3nM
    def Xprof(t):
        return PRR7_interpolation(t)/max_x*3

    ## X profile array.
    Xtot = []
    for i in t:
        Xtot.append(Xprof(i))

    ##R value interpolation
    fun_R = interp1d(t_eval, R)

    # calculating R with new time intervals.
    R = []
    for i in t:
        if i<1:
            R.append(fun_R(i+24))
        elif i>24:
            R.append(fun_R((i-1)%24+1))
        else:
            R.append(fun_R(i))
    R = np.array(R)

    Rmax = max(R)
    Xmax = max(Xtot)
    Xmin = min(Xtot)

    file = open("./model0_result.csv",'w')
    file.write("a0,a1,a2,b0,b1,\
       q,s,r0,u,v,\
            feasible,cost,alpha_D,similarity\n")
    file.close()

    num_of_trial=1
    for jj in range(num_of_trial):
        para = [0 for i in range(17)]
        a0 = para[0] = rd.uniform(180,4800)
        a1 = para[1] = rd.uniform(420,18000)
        a2 = para[2] = rd.uniform(180,18000)
        b0 = para[3] = rd.uniform(180,4800)
        b1 = para[4] = rd.uniform(180,18000)
        q = para[7] = rd.uniform(30,1200)
        s = para[8] = rd.uniform(30,1200)
        c = para[10] = rd.uniform(Rmax,5)
        u = rd.uniform(0.1 ,1)
        v = rd.uniform(0,1)
        y = rd.uniform(30,300)
        z = rd.uniform(0,300)

        coef_u = a0/c*q/(a1+q)
        coef_v = b0/c*(c+s)/(b1+c+s)

        U = para[13] = coef_u * u
        V = para[14] = coef_v * v

        para, feasible, cost, alphaD, sim = ode_solve(para, Xmax, Xmin, Rmax, R, Xtot, dt, t, rt_est_PRR7, Xprof)

        ## writing file
        file = open("./model0_result.csv",'a')

        file.write(str(a0)+",")
        file.write(str(a1)+",")
        file.write(str(a2)+",")
        file.write(str(b0)+",")
        file.write(str(b1)+",")
        file.write(str(q)+",")
        file.write(str(s)+",")
        file.write(str(c)+",")
        file.write(str(u)+",")
        file.write(str(v)+",")
        file.write(str(feasible)+",")
        file.write(str(cost)+",")
        file.write(str(alphaD)+",")
        file.write(str(sim)+",")
        file.write("\n")
        file.close()

main()
