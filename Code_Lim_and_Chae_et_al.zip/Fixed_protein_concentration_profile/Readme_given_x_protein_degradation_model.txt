File name: given_x_protein_degradation_model.py


*** System requirements
- Windows, Linux or macOS
- Python 3.5 or later
- "given_x_protein_degradation_model.py" requires the following Python packages:
  sys, copy, numpy, scipy, and pandas
Installing the required Python packages does not take long time (less than 10
minutes).


*** General information
When a protein abundance profile x(t) is maintained, this code solves the protein
degradation models with the following conditions:
- # of phosphorylation events (n) = 0, 1, 2, 3, and 4;
- v = 0 (V = 0);
- z = 0 (Z = 0);
User assigned model parameter values, "a0","a1","a2","r0","k","q","U", and "Y",
are used for solving the protein degradation model n=0, 1, 2, 3, and 4.


*** Input
The main module of this code is "simulation_given_x". The main module requires
two input files, "given_x_model_parameter_n1.csv" and
"given_x_new_model_parameter_all.csv". These three files are in CSV
(comma-separated values) format. "given_x_model_parameter_n1.csv" is used to
generate a protein abundance using the protein degradation model for n=1.
The protein synthesis rate in the protein degradation model n=1 has the
following form:
- g(t) = g_L – g_L*alpha_g/(2 – alpha_g)*cos(2*pi/T_period*(t - t_off)).
"given_x_model_parameter_n1.csv" contains the followings:
- "a0" is the binding rate (in nM^-1 h^-1) between ubiquitin ligase and
  substrate protein for the protein degradation model n=1.
- "a1" is the dissociation rate (in h^-1) between ubiquitin ligase and
  not-ubiquitinated substrate protein for the protein degradation model n=1.
- "a2" is the dissociation rate (in h^-1) between ubiquitin ligase and
  ubiquitinated protein for the protein degradation model n=1.
- "r0" is the degradation rate (in h^-1) of a ubiquitinated protein for the
  protein degradation model n=1.
- "k" is the binding rate (in nM^-1 h^-1) between protein kinase and substrate
  protein, lumped with a phosphorylation event followed by substrate
  dissociation for the protein degradation model n=1.
- "q" is the ubiquitination rate (in h^-1) of a protein binding to a ubiquitin
  ligase for the protein degradation model n=1.
- "U" is the dimensionless quantity proportional to the total concentration of
  ubiquitin ligase for the protein degradation model n=1.
- "Y" is the dimensionless quantity proportional to the total concentration of
  kinase for the protein degradation model n=1.
- "g_L" (in nM h^-1), "alpha_g" (dimensionless), and "t_off" (in h) are the
  parameter values for g(t) in the protein degradation model n=1.
The code assumes that v =0. Thus, the values of "x_H_ub(t)" are zeros in
the protein degradation model n=0, 1, 2, 3, and 4. The values of "b0", "b1",
and "s" are not required in the code. The value of parameter "l" is not
required because z = 0.

"given_x_new_model_parameter_all.csv" contains user assigned model parameters,
"a0", "a1", "a2", "r0", "k", "q", "U", and "Y", for the protein degradation
model n=0, 1, 2, 3, and 4.


*** Output
The main module "simulation_given_x" writes
- a data file for the protein abundance
- and data files containing the solutions to the protein degradation model
n=0, 1, 2, 3, and 4 with the user assigned model parameters.
All the data files are saved in the CSV file format. The data file for the
given protein abundance is saved as "given_x.csv". "given_x.csv" consists of
the followings:
- the time points at which to store the computed solutions,
- the concentrations of x at the time points,
- the values of x'(t) at the time points,
- the values of R(t)= -1.0/r0*[x'(t)/x(t)] at the time points,
- and the concentrations of proteins in the protein degradation model n=1.

The solutions to the protein degradation model n=0, 1, 2, 3, and 4 with the
user assigned model parameters are saved as "given_x_n0.csv",
"given_x_n1.csv", "given_x_n2.csv", "given_x_n3.csv", and "given_x_n4.csv",
respectively. The each file has
- the time points at which to store the computed solutions,
- the concentrations of proteins in the corresponding protein degradation
  model at the time points,
- and the dimensionless degradation rate (D) at the time points.


*** Demos
We provide sample input files "given_x_model_parameter_n1.csv" and
"given_x_new_model_parameter_all.csv". In the code, the simulation time
inverval is (0.0,480.0) with a uniform time step size 0.05. Running
"given_x_protein_degradation_model.py" with the given input files and
the settings takes about 40 minutes on a "normal desktop".


*** Contact information
This code was written by Roktaek Lim. If you have any question,
please contact R. Lim via "rokt.lim@gmail.com".
