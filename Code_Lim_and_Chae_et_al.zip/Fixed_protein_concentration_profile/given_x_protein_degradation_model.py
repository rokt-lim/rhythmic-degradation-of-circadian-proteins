# -*- coding: utf-8 -*-
"""
When a protein abundance profile is given,
this code solves the protein degradation model with
the following conditions:
- # of phosphorylation events = 0, 1, 2, 3, 4,
- v(t) = 0,
- z(t) = 0.

@author: LIM Roktaek
@e-mail: rokt.lim@gmail.com
"""

####-- Modules

import sys
import copy
import numpy
import pandas
from scipy.integrate import solve_ivp

####-- END Modules

####-- Functions

###-- protein synthesis rate
def g_function(g_L,alpha_g,t_off,T_period,t_eval):
    g_t = g_L - g_L*alpha_g/(2.0 - alpha_g)*numpy.cos(2.0*numpy.pi/T_period*(t_eval-t_off))
    return g_t
###

###-- ODE function: np = 1 with g_t
def model_np1_ODE(a0,a1,a2,r0,k,q,g_t,u_t,y_t,x):
    dx_dt = numpy.zeros(x.shape)
    dx_dt[0,:] = g_t - k*y_t*x[0,:]
    dx_dt[1,:] = k*y_t*x[0,:] - a0*u_t*x[1,:] + a1*x[2,:]
    dx_dt[2,:] = a0*u_t*x[1,:] - a1*x[2,:] - q*x[2,:]
    dx_dt[3,:] = q*x[2,:] + a0*u_t*x[4,:] - a2*x[3,:] - r0*x[3,:]
    dx_dt[4,:] = a2*x[3,:] - a0*u_t*x[4,:] - r0*x[4,:]
    #-- return
    return dx_dt
###

###
def dX_dt_np1_given_G(t,y,pv):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    # # -- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- return
    return dy_dt
###

###
def dX_dt_np1_given_X_np0(t,y,pv,pv_new):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    #-- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- variables for n = 0
    # x_e_0  = y[5]
    # x_e_ub = y[6]
    # x_0_ub = y[7]
    #-- model parameters for n = 0
    a0 = pv_new[0]
    a1 = pv_new[1]
    a2 = pv_new[2]
    r0 = pv_new[3]
    k  = pv_new[4]
    q  = pv_new[5]
    U_tau = pv_new[6]
    Y_tau = pv_new[7]
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    x_n = y[0] + y[1] + y[2] + y[3] + y[4] - numpy.sum(y[5:])
    u_t = X_coeff_inv*U_tau - y[5] - y[6]
    dy_dt[5] = a0*u_t*x_n - a1*y[5] - q*y[5]
    dy_dt[6] = q*y[5] + a0*u_t*y[7] - a2*y[6] - r0*y[6]
    dy_dt[7] = a2*y[6] - a0*u_t*y[7] - r0*y[7]
    return dy_dt
###

###
def dX_dt_np1_given_X_np1(t,y,pv,pv_new):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    #-- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- variables for n = 1
    # x_p    = y[5]
    # x_e_0  = y[6]
    # x_e_ub = y[7]
    # x_0_ub = y[8]
    #-- model parameters for n = 1
    a0 = pv_new[0]
    a1 = pv_new[1]
    a2 = pv_new[2]
    r0 = pv_new[3]
    k  = pv_new[4]
    q  = pv_new[5]
    U_tau = pv_new[6]
    Y_tau = pv_new[7]
    x_n = y[0] + y[1] + y[2] + y[3] + y[4] - numpy.sum(y[5:])
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[6] - y[7]
    y_t = r0*Y_tau/k
    dy_dt[5] = k*y_t*x_n - a0*u_t*y[5] + a1*y[6]
    dy_dt[6] = a0*u_t*y[5] - a1*y[6] - q*y[6]
    dy_dt[7] = q*y[6] + a0*u_t*y[8] - a2*y[7] - r0*y[7]
    dy_dt[8] = a2*y[7] - a0*u_t*y[8] - r0*y[8]
    #-- return
    return dy_dt
###

###
def dX_dt_np1_given_X_np2(t,y,pv,pv_new):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    #-- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- variables for n = 2
    # x_p_1 = y[5]
    # x_p_2 = y[6]
    # x_e_0  = y[7]
    # x_e_ub = y[8]
    # x_0_ub = y[9]
    #-- model parameters for n = 2
    a0 = pv_new[0]
    a1 = pv_new[1]
    a2 = pv_new[2]
    r0 = pv_new[3]
    k  = pv_new[4]
    q  = pv_new[5]
    U_tau = pv_new[6]
    Y_tau = pv_new[7]
    x_n = y[0] + y[1] + y[2] + y[3] + y[4] - numpy.sum(y[5:])
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[7] - y[8]
    y_t = r0*Y_tau/k
    dy_dt[5] = k*y_t*x_n - k*y_t*y[5]
    dy_dt[6] = k*y_t*y[5] - a0*u_t*y[6] + a1*y[7]
    dy_dt[7] = a0*u_t*y[6] - a1*y[7] - q*y[7]
    dy_dt[8] = q*y[7] + a0*u_t*y[9] - a2*y[8] - r0*y[8]
    dy_dt[9] = a2*y[8] - a0*u_t*y[9] - r0*y[9]
    return dy_dt
###

###
def dX_dt_np1_given_X_np3(t,y,pv,pv_new):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    #-- variables
    # x_0   = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- variables for n = 3
    # x_p_1 = y[5]
    # x_p_2 = y[6]
    # x_p_3 = y[7]
    # x_e_0  = y[8]
    # x_e_ub = y[9]
    # x_0_ub = y[10]
    #-- model parameters for n = 3
    a0 = pv_new[0]
    a1 = pv_new[1]
    a2 = pv_new[2]
    r0 = pv_new[3]
    k  = pv_new[4]
    q  = pv_new[5]
    U_tau = pv_new[6]
    Y_tau = pv_new[7]
    x_n = y[0] + y[1] + y[2] + y[3] + y[4] - numpy.sum(y[5:])
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[8] - y[9]
    y_t = r0*Y_tau/k
    dy_dt[5]  = k*y_t*x_n - k*y_t*y[5]
    dy_dt[6]  = k*y_t*y[5] - k*y_t*y[6]
    dy_dt[7]  = k*y_t*y[6] - a0*u_t*y[7] + a1*y[8]
    dy_dt[8]  = a0*u_t*y[7] - a1*y[8] - q*y[8]
    dy_dt[9]  = q*y[8] + a0*u_t*y[10] - a2*y[9] - r0*y[9]
    dy_dt[10] = a2*y[9] - a0*u_t*y[10] - r0*y[10]
    return dy_dt
###

###
def dX_dt_np1_given_X_np4(t,y,pv,pv_new):
    #-- parameters
    a0 = pv[0]
    a1 = pv[1]
    a2 = pv[2]
    r0 = pv[3]
    k  = pv[4]
    q  = pv[5]
    T_period = pv[6]
    g_L  = pv[7]
    g_alpha = pv[8]
    t_off = pv[9]
    U_tau = pv[10]
    Y_tau = pv[11]
    #-- dy/dt
    dy_dt = numpy.zeros(y.shape)
    # # -- variables
    # x_0    = y[0]
    # x_p    = y[1]
    # x_e_0  = y[2]
    # x_e_ub = y[3]
    # x_0_ub = y[4]
    #-- g(t)
    g_t = g_L - g_L*g_alpha/(2.0 - g_alpha)*numpy.cos(2.0*numpy.pi/T_period*(t - t_off))
    #-- ordinary differential equations
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[2] - y[3]
    y_t = r0*Y_tau/k
    dy_dt[0] = g_t - k*y_t*y[0]
    dy_dt[1] = k*y_t*y[0] - a0*u_t*y[1] + a1*y[2]
    dy_dt[2] = a0*u_t*y[1] - a1*y[2] - q*y[2]
    dy_dt[3] = q*y[2] + a0*u_t*y[4] - a2*y[3] - r0*y[3]
    dy_dt[4] = a2*y[3] - a0*u_t*y[4] - r0*y[4]
    #-- variables for n = 4
    # x_p_1 = y[5]
    # x_p_2 = y[6]
    # x_p_3 = y[7]
    # x_p_4 = y[8]
    # x_e_0  = y[9]
    # x_e_ub = y[10]
    # x_0_ub = y[11]
    #-- model parameters for n = 4
    a0 = pv_new[0]
    a1 = pv_new[1]
    a2 = pv_new[2]
    r0 = pv_new[3]
    k  = pv_new[4]
    q  = pv_new[5]
    U_tau = pv_new[6]
    Y_tau = pv_new[7]
    x_n = numpy.sum(y[0:5]) - numpy.sum(y[5:])
    # x_n = y[0] + y[1] + y[2] + y[3] + y[4] - numpy.sum(y[5:])
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    u_t = X_coeff_inv*U_tau - y[9] - y[10]
    y_t = r0*Y_tau/k
    dy_dt[5]  = k*y_t*x_n - k*y_t*y[5]
    dy_dt[6]  = k*y_t*y[5] - k*y_t*y[6]
    dy_dt[7]  = k*y_t*y[6] - k*y_t*y[7]
    dy_dt[8]  = k*y_t*y[7] - a0*u_t*y[8] + a1*y[9]
    dy_dt[9]  = a0*u_t*y[8] - a1*y[9] - q*y[9]
    dy_dt[10] = q*y[9] + a0*u_t*y[11] - a2*y[10] - r0*y[10]
    dy_dt[11] = a2*y[10] - a0*u_t*y[11] - r0*y[11]
    return dy_dt
###

###
def solution_feasibility(tag,D_t,R_t):
    D_t_R_t = D_t - R_t
    if numpy.min(D_t_R_t) >= 0.0:
        print(tag + ', feasible')
    else:
        print(tag + ', infeasible')
    #
    #-- return
    return 0
###

###
def solution_flag(X_coeff_inv,U_tau,x_sol,tag_e_0,tag_e_ub):
    n_v,_ = x_sol.shape
    #-- check variables, negative values
    neg_flag_check = []
    for ix in range(0,n_v):
        tmp = numpy.amin(x_sol[ix,:])
        if tmp < -1.0e-6:
            neg_flag_check.append('1')
        else:
            neg_flag_check.append('0')
        #
    #
    if '1' in neg_flag_check:
        pos_flag = 'fail'
    else:
        pos_flag = 'pass'
    #
    #-- compute u_t
    u_t = X_coeff_inv*U_tau - x_sol[tag_e_0,:] - x_sol[tag_e_ub,:]
    u_flag = 'pass'
    if numpy.amin(u_t) < 0.0:
        print(numpy.amin(u_t))
        u_flag = 'fail'
    #
    return '|'.join([pos_flag,u_flag])
###

###
def simulation_given_x(model_p_name,new_model_p_name):
    #-- read model parameters
    df_p = pandas.read_csv(model_p_name)
    a0 = df_p.loc[0,'a0']
    a1 = df_p.loc[0,'a1']
    a2 = df_p.loc[0,'a2']
    r0 = df_p.loc[0,'r0']
    k  = df_p.loc[0,'k']
    q  = df_p.loc[0,'q']
    U_tau = df_p.loc[0,'U']
    Y_tau = df_p.loc[0,'Y']
    X_coeff_inv = r0*(a1 + q)/(a0*q)
    #-- read parameters for g(t)
    g_L = df_p.loc[0,'g_L']
    g_alpha = df_p.loc[0,'g_alpha']
    t_off = df_p.loc[0,'t_off']
    #-- parameters for ivp_solver
    T_period = 24.0
    t_start  = 0.0
    t_end    = 20.0*T_period
    dt       = 0.05
    tp = numpy.linspace(t_start,t_end,int((t_end-t_start)/dt) + 1)
    x_init = numpy.zeros((5,))
    x_init[0] = 1.0
    pv = [a0,a1,a2,r0,k,q,T_period,g_L,g_alpha,t_off,U_tau,Y_tau]
    #-- compute default x profile
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_G(t,y,pv),\
                    t_span=[t_start,t_end], y0=x_init, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_sol = copy.deepcopy(sol.y)
    x_tot = numpy.sum(x_sol,axis=0)
    g_t = g_function(g_L,g_alpha,t_off,T_period,sol.t)
    u_t = X_coeff_inv*U_tau - x_sol[2,:] - x_sol[3,:]
    y_t = r0*Y_tau/k
    dx_dt = model_np1_ODE(a0,a1,a2,r0,k,q,g_t,u_t,y_t,x_sol)
    dx_tot_dt = numpy.sum(dx_dt,axis=0)
    R_t = (-1.0/r0)*numpy.divide(dx_tot_dt,x_tot)
    D_t = numpy.divide(x_sol[3,:] + x_sol[4,:],x_tot)
    df_given_x = pandas.DataFrame({ 't'      : sol.t,
                                    'x'      : x_tot,
                                    'dxdt'   : dx_tot_dt,
                                    'R'      : R_t,
                                    'x_0'    : x_sol[0,:],
                                    'x_p'    : x_sol[1,:],
                                    'x_E_0'  : x_sol[2,:],
                                    'x_E_ub' : x_sol[3,:],
                                    'x_0_ub' : x_sol[4,:] })
    df_given_x.to_csv('given_x.csv',index=False)
    flag = solution_flag(X_coeff_inv,U_tau,x_sol,2,3)
    print('solution using model parameters, flag:',flag)
    solution_feasibility('solution using model parameters',D_t,R_t)
    #-- read new model parameters
    df_new = pandas.read_csv(new_model_p_name)
    a0 = df_new.loc[0,'a0']
    a1 = df_new.loc[0,'a1']
    a2 = df_new.loc[0,'a2']
    r0 = df_new.loc[0,'r0']
    k  = df_new.loc[0,'k']
    q  = df_new.loc[0,'q']
    U_tau = df_new.loc[0,'U']
    Y_tau = df_new.loc[0,'Y']
    X_coeff_inv_new = r0*(a1 + q)/(a0*q)
    pv_new = [a0,a1,a2,r0,k,q,U_tau,Y_tau]
    #-- solve IVP, n = 0
    y_0 = numpy.concatenate((x_init,numpy.zeros(3,)))
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_X_np0(t,y,pv,pv_new),\
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_new = numpy.zeros((4,len(tp)))
    x_new[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_e_0
    x_new[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_e_ub
    x_new[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_0_ub
    x_new[0,:] = x_tot - numpy.sum(x_new[1:,:],axis=0) #-- x_0
    D_t = numpy.divide(x_new[2,:] + x_new[3,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_new[0,:],
                                'x_E_0'  : x_new[1,:],
                                'x_E_ub' : x_new[2,:],
                                'x_0_ub' : x_new[3,:],
                                'D'      : D_t })
    df_sol.to_csv('given_x_n0.csv',index=False)
    flag = solution_flag(X_coeff_inv_new,U_tau,x_new,1,2)
    print('\nn=0, flag:',flag)
    solution_feasibility('n=0',D_t,R_t)
    #-- solve IVP, n = 1
    y_0 = numpy.concatenate((x_init,numpy.zeros(4,)))
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_X_np1(t,y,pv,pv_new),\
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_new = numpy.zeros((5,len(tp)))
    x_new[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_p
    x_new[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_e_0
    x_new[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_e_ub
    x_new[4,:] = copy.deepcopy(sol.y[8,:]) #-- x_0_ub
    x_new[0,:] = x_tot - numpy.sum(x_new[1:,:],axis=0) #-- x_0
    D_t = numpy.divide(x_new[3,:] + x_new[4,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_new[0,:],
                                'x_p'    : x_new[1,:],
                                'x_E_0'  : x_new[2,:],
                                'x_E_ub' : x_new[3,:],
                                'x_0_ub' : x_new[4,:],
                                'D'      : D_t })
    df_sol.to_csv('given_x_n1.csv',index=False)
    flag = solution_flag(X_coeff_inv_new,U_tau,x_new,2,3)
    print('\nn=1, flag:',flag)
    solution_feasibility('n=1',D_t,R_t)
    #-- solve IVP, n = 2
    y_0 = numpy.concatenate((x_init,numpy.zeros(5,)))
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_X_np2(t,y,pv,pv_new),\
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_new = numpy.zeros((6,len(tp)))
    x_new[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_p_1
    x_new[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_p_2
    x_new[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_e_0
    x_new[4,:] = copy.deepcopy(sol.y[8,:]) #-- x_e_ub
    x_new[5,:] = copy.deepcopy(sol.y[9,:]) #-- x_0_ub
    x_new[0,:] = x_tot - numpy.sum(x_new[1:,:],axis=0) #-- x_0
    D_t = numpy.divide(x_new[4,:] + x_new[5,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_new[0,:],
                                'x_p_1'  : x_new[1,:],
                                'x_p_2'  : x_new[2,:],
                                'x_E_0'  : x_new[3,:],
                                'x_E_ub' : x_new[4,:],
                                'x_0_ub' : x_new[5,:],
                                'D'      : D_t })
    df_sol.to_csv('given_x_n2.csv',index=False)
    flag = solution_flag(X_coeff_inv_new,U_tau,x_new,3,4)
    print('\nn=2, flag:',flag)
    solution_feasibility('n=2',D_t,R_t)
    #-- solve IVP, n = 3
    y_0 = numpy.concatenate((x_init,numpy.zeros(6,)))
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_X_np3(t,y,pv,pv_new),\
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_new = numpy.zeros((7,len(tp)))
    x_new[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_p_1
    x_new[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_p_2
    x_new[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_p_3
    x_new[4,:] = copy.deepcopy(sol.y[8,:]) #-- x_e_0
    x_new[5,:] = copy.deepcopy(sol.y[9,:]) #-- x_e_ub
    x_new[6,:] = copy.deepcopy(sol.y[10,:]) #-- x_0_ub
    x_new[0,:] = x_tot - numpy.sum(x_new[1:,:],axis=0) #-- x_0
    D_t = numpy.divide(x_new[5,:] + x_new[6,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_new[0,:],
                                'x_p_1'  : x_new[1,:],
                                'x_p_2'  : x_new[2,:],
                                'x_p_3'  : x_new[3,:],
                                'x_E_0'  : x_new[4,:],
                                'x_E_ub' : x_new[5,:],
                                'x_0_ub' : x_new[6,:],
                                'D'      : D_t })
    df_sol.to_csv('given_x_n3.csv',index=False)
    flag = solution_flag(X_coeff_inv_new,U_tau,x_new,4,5)
    print('\nn=3, flag:',flag)
    solution_feasibility('n=3',D_t,R_t)
    #-- solve IVP, n = 4
    y_0 = numpy.concatenate((x_init,numpy.zeros(7,)))
    sol = solve_ivp(fun=lambda t, y: dX_dt_np1_given_X_np4(t,y,pv,pv_new),\
                    t_span=[t_start,t_end], y0=y_0, method='RK45',\
                    t_eval=tp, max_step=dt, rtol=1e-5, atol=1e-5)
    x_new = numpy.zeros((8,len(tp)))
    x_new[1,:] = copy.deepcopy(sol.y[5,:]) #-- x_p_1
    x_new[2,:] = copy.deepcopy(sol.y[6,:]) #-- x_p_2
    x_new[3,:] = copy.deepcopy(sol.y[7,:]) #-- x_p_3
    x_new[4,:] = copy.deepcopy(sol.y[8,:]) #-- x_p_4
    x_new[5,:] = copy.deepcopy(sol.y[9,:]) #-- x_e_0
    x_new[6,:] = copy.deepcopy(sol.y[10,:]) #-- x_e_ub
    x_new[7,:] = copy.deepcopy(sol.y[11,:]) #-- x_0_ub
    x_new[0,:] = x_tot - numpy.sum(x_new[1:,:],axis=0) #-- x_0
    D_t = numpy.divide(x_new[6,:] + x_new[7,:],x_tot)
    df_sol = pandas.DataFrame({ 't'      : sol.t,
                                'x_0'    : x_new[0,:],
                                'x_p_1'  : x_new[1,:],
                                'x_p_2'  : x_new[2,:],
                                'x_p_3'  : x_new[3,:],
                                'x_p_4'  : x_new[4,:],
                                'x_E_0'  : x_new[5,:],
                                'x_E_ub' : x_new[6,:],
                                'x_0_ub' : x_new[7,:],
                                'D'      : D_t })
    df_sol.to_csv('given_x_n4.csv',index=False)
    flag = solution_flag(X_coeff_inv_new,U_tau,x_new,5,6)
    print('\nn=4, flag:',flag)
    solution_feasibility('n=4',D_t,R_t)
    return 0
###

####-- END Functions

####-- Main script

simulation_given_x('given_x_model_parameter_n1.csv','given_x_new_model_parameter_all.csv')

####-- END ---####
